/* Quark: module-drawn knob-cell widgets (Schwung `drawCell`, docs/MODULES.md "Custom widgets").
 *
 *  custom:qwave  Type + Variation as ONE picture: the actual single cycle the Atmos engine plays
 *                for that type at that Variation (string registers, wavetable frame, FM index). The
 *                Variation key is `live`, so Motion shows as a moving wave. A tick under the
 *                wave marks Variation; three dots name the family (1 strings, 2 wavetable, 3 FM).
 *  custom:qline  Melody Shape + Variation: the oscillator shape (with the PWM the macro adds) and a
 *                three-segment meter for Variation's PWM -> tremolo -> vibrato stages; for a wavetable
 *                shape, the wave at that position and a position tick.
 *  custom:qdrive Atmos Drive + Position: the transfer curve the drive applies (it bends and flattens
 *                as Drive rises), a sine through it, and PRE / POST / AMP.
 *  custom:qdet   Atmos Detune + Bloom: the notes of a chord as lines that start together and fan out
 *                to their detune offsets over the Bloom time.
 *  custom:qpcm   PCM Layer (its own cell) and Layer Start + Mode (one group): the Layer set's level
 *                outline, a bracket over its loop, a Start tick and a Mode glyph (a loop arrow or a
 *                one-shot bar; boxed for the post-filter modes). Off: a dotted flat line.
 *  custom:qera   PCM Era: a sine drawn the way that Era reads the ROM (smooth / coarse / stepped).
 *  custom:qflt   Atmos Cutoff + Resonance: the response of the selected Filter Type (read from the
 *                page's values), including the combs' teeth, Dual BP's two bands and Morph's blend.
 *
 * (0,0) is the cell box, ctx.width/height its size; values arrive, never read (no getParam).
 */
(function () {
  /* BEGIN GENERATED */
var QUARK_META = {"params":[{"key":"tx_type","name":"Atmos Type","short":"Type","kind":"e","mn":0,"mx":147,"default":0,"opts":["Strings","Vintage","Brass","Organ","Choir","Poly Saw","Square","Drawbar","Reed","Resonant","Mallet","Bellish","Add Harm","Vocal","Glass","Fifths","Minor 9","Major 9","Dom 11","Fourths","E.Piano","FM Bells","FM Keys","FM Glass","Metal","FM Pad","Basic","Pulse","Resonant WT","Resonant 2","Sync","Formant A","Formant B","Harmonic","Odd","Bell","Organ WT","Digital","Noise","PWM Saw","Fold","Steps","Strings WT","Brass WT","Bass Spectra","Choir WT","Glass WT","Chaos","Comb","PhaseDist","Fractal","Upper","Clav","Breath","SqSync","Metal WT","Stack","Granite","Cello","Violin","Voice","EPiano","Clavinet","E-Organ","FM","Chip","VGame","Sax","Flute","Overtone","Crushed","Granular","Upright","Piano","Even","Partials","Feedback","Window","Rave","Octaves","Logic","Reed WT","Pluck","Sweep","Chord","Vosim","Scanned","Prime","SineSync","Mallet WT","Mixer","Sub","Notch","Drive","E-Bass","E-Guitar","Distorted","Theremin","Raw","Drawn","Wine Glass","Bowed Vibes","Section Strings","Psaltery","Concert Flute","Ocarina","Organ Blower","Ocean Drum","Cymbal Bow","Gong Scrape","Hand Chimes","Soft Vibes","Glock","Kalimba","Pipe Organ","Digi E.Piano","Aah","Ooh","Sung Chord","Dream Chord","Breath Loop","Shakuhachi","Shaku Breath","Sitar","Tanpura","Dan Tranh","Duduk","Erhu","Sarangi","Koto","Singing Bowl","Didgeridoo","User 1","User 2","User 3","User 4","User 5","User 6","User 7","User 8","User 9","User 10","User 11","User 12","User 13","User 14","User 15","User 16"],"sopts":["Str","Vint","Bras","Orgn","Chor","PSaw","Sqr","Draw","Reed","Reso","Malt","Bell","Add","Vox","Glas","5ths","Min9","Maj9","Dm11","4ths","EP","FMBl","Keys","FMGl","Metl","FMPd","Basi","Puls","RsWT","Res2","Sync","Frmn","Form","Hrmn","Odd","Blll","OrWT","Dgtl","Nois","PWMS","Fold","Stps","StWT","BrWT","BssS","ChWT","GlWT","Chao","Comb","PhsD","Frct","Uppr","Clav","Brth","SqSy","MtWT","Stck","Grnt","Cell","Viol","Voic","EPia","Clvn","Ergn","FM","Chip","VGam","Sax","Flut","Ovrt","Crsh","Grnl","Uprg","Pian","Even","Prtl","Fdbc","Wndw","Rave","Octv","Logi","RdWT","Plck","Swee","Chrd","Vosi","Scnn","Prim","SnSy","MlWT","Mixe","Sub","Ntch","Driv","EBss","EGtr","Dstr","Thrm","Raw","Drwn","WGls","BVib","SStr","Psal","CFlt","Ocar","Blwr","Ocn","Cymb","Gong","Chim","SVib","Glck","Kalm","POrg","DEP","Aah","Ooh","SChd","Drm","BrLp","Shak","ShBr","Sitr","Tanp","DanT","Dudk","Erhu","Sarg","Koto","Bowl","Didg","U1","U2","U3","U4","U5","U6","U7","U8","U9","U10","U11","U12","U13","U14","U15","U16"],"viz":{"group":"txw","role":"type","kind":"custom:qwave"},"card":"cards.js#quark_card"},{"key":"tx_var","name":"Variation","short":"Var","kind":"f","mn":0.0,"mx":1.0,"default":0.3,"unit":null,"viz":{"group":"txw","role":"variation","kind":"custom:qwave"},"live":true,"card":"cards.js#quark_card"},{"key":"tx_anim","name":"Motion","short":"Mot","kind":"f","mn":0.0,"mx":1.0,"default":0.25,"unit":null},{"key":"tx_depth","name":"Var Env","short":"VrEnv","kind":"f","mn":-1.0,"mx":1.0,"default":0.0,"unit":null},{"key":"tx_a","name":"Atmos Attack","short":"Atk","kind":"f","mn":0.0,"mx":1.0,"default":0.32,"unit":null,"viz":{"group":"tx","role":"attack","kind":"envelope"}},{"key":"tx_d","name":"Atmos Decay","short":"Dec","kind":"f","mn":0.0,"mx":1.0,"default":0.5,"unit":null,"viz":{"group":"tx","role":"decay","kind":"envelope"}},{"key":"tx_s","name":"Atmos Sustain","short":"Sus","kind":"f","mn":0.0,"mx":1.0,"default":0.85,"unit":null,"viz":{"group":"tx","role":"sustain","kind":"envelope"}},{"key":"tx_r","name":"Atmos Release","short":"Rel","kind":"f","mn":0.0,"mx":1.0,"default":0.5,"unit":null,"viz":{"group":"tx","role":"release","kind":"envelope"}},{"key":"ln_shape","name":"Melody Shape","short":"Shape","kind":"e","mn":0,"mx":108,"default":0,"opts":["Saw","Pulse","Saw+Pulse","Sync","Poly Saw","Square","Drawbar","Reed","Resonant","Mallet","Bellish","Add Harm","Vocal","Glass","Fifths","Minor 9","Major 9","Dom 11","Fourths","Basic","Pulse WT","Resonant WT","Resonant 2","Sync WT","Formant A","Formant B","Harmonic","Odd","Bell","Organ WT","Digital","Noise","PWM Saw","Fold","Steps","Strings WT","Brass WT","Bass Spectra","Choir WT","Glass WT","Chaos","Comb","PhaseDist","Fractal","Upper","Clav","Breath","SqSync","Metal WT","Stack","Granite","Cello","Violin","Voice","EPiano","Clavinet","E-Organ","FM","Chip","VGame","Sax","Flute","Overtone","Crushed","Granular","Upright","Piano","Even","Partials","Feedback","Window","Rave","Octaves","Logic","Reed WT","Pluck","Sweep","Chord","Vosim","Scanned","Prime","SineSync","Mallet WT","Mixer","Sub","Notch","Drive","E-Bass","E-Guitar","Distorted","Theremin","Raw","Drawn","User 1","User 2","User 3","User 4","User 5","User 6","User 7","User 8","User 9","User 10","User 11","User 12","User 13","User 14","User 15","User 16"],"sopts":["Saw","Puls","S+P","Sync","PSaw","Sqr","Draw","Reed","Reso","Malt","Bell","Add","Vox","Glas","5ths","Min9","Maj9","Dm11","4ths","Basi","PeWT","RsWT","Res2","ScWT","Frmn","Form","Hrmn","Odd","Blll","OrWT","Dgtl","Nois","PWMS","Fold","Stps","StWT","BrWT","BssS","ChWT","GlWT","Chao","Comb","PhsD","Frct","Uppr","Clav","Brth","SqSy","MtWT","Stck","Grnt","Cell","Viol","Voic","EPia","Clvn","Ergn","FM","Chip","VGam","Sax","Flut","Ovrt","Crsh","Grnl","Uprg","Pian","Even","Prtl","Fdbc","Wndw","Rave","Octv","Logi","RdWT","Plck","Swee","Chrd","Vosi","Scnn","Prim","SnSy","MlWT","Mixe","Sub","Ntch","Driv","EBss","EGtr","Dstr","Thrm","Raw","Drwn","U1","U2","U3","U4","U5","U6","U7","U8","U9","U10","U11","U12","U13","U14","U15","U16"],"viz":{"group":"lnw","role":"shape","kind":"custom:qline"},"card":"cards.js#quark_card"},{"key":"ln_var","name":"Melody Variation","short":"Var","kind":"f","mn":0.0,"mx":1.0,"default":0.15,"unit":null,"viz":{"group":"lnw","role":"variation","kind":"custom:qline"},"card":"cards.js#quark_card"},{"key":"ln_a","name":"Melody Attack","short":"Atk","kind":"f","mn":0.0,"mx":1.0,"default":0.04,"unit":null,"viz":{"group":"ln","role":"attack","kind":"envelope"}},{"key":"ln_d","name":"Melody Decay","short":"Dec","kind":"f","mn":0.0,"mx":1.0,"default":0.42,"unit":null,"viz":{"group":"ln","role":"decay","kind":"envelope"}},{"key":"ens_amt","name":"Atmos Ensemble","short":"Ens","kind":"f","mn":0.0,"mx":1.0,"default":0.65,"unit":null},{"key":"tx_vol","name":"Atmos Volume","short":"AtVol","kind":"f","mn":0.0,"mx":1.0,"default":0.8,"unit":null,"viz":{"kind":"fader"}},{"key":"ln_vol","name":"Melody Volume","short":"MlVol","kind":"f","mn":0.0,"mx":1.0,"default":0.0,"unit":null,"viz":{"kind":"fader"}},{"key":"vintage","name":"Vintage","short":"Vint","kind":"f","mn":0.0,"mx":1.0,"default":0.25,"unit":null},{"key":"fx_ctrl","name":"Effect Control","short":"Ctrl","kind":"f","mn":0.0,"mx":1.0,"default":0.3,"unit":null,"card":"cards.js#quark_card","card_w":110,"card_h":17},{"key":"fx_amt","name":"Effect Amount","short":"FxAmt","kind":"f","mn":0.0,"mx":1.0,"default":0.0,"unit":null},{"key":"sh_pitch","name":"Shimmer Pitch","short":"Pitch","kind":"e","mn":0,"mx":7,"default":5,"opts":["-12","-7","-5","+5","+7","+12","+19","+24"],"sopts":null,"card":"cards.js#quark_card"},{"key":"sh_amt","name":"Shimmer Amount","short":"Shim","kind":"f","mn":0.0,"mx":1.0,"default":0.0,"unit":null,"card":"cards.js#quark_card"},{"key":"rv_decay","name":"Reverb Decay","short":"Decay","kind":"f","mn":0.0,"mx":1.0,"default":0.5,"unit":null},{"key":"rv_amt","name":"Reverb Amount","short":"Rvb","kind":"f","mn":0.0,"mx":1.0,"default":0.28,"unit":null},{"key":"fx_type","name":"Effect Type","short":"FxTyp","kind":"e","mn":0,"mx":10,"default":0,"opts":["Chorus","Chorus 2","Flanger","Flanger 2","Phaser","Phaser 2","Tremolo","Drive","Delay","Ping Pong","Tape Echo"],"sopts":["Cho","Cho2","Flng","Flg2","Phas","Phs2","Trem","Drv","Dly","Ping","Tape"]},{"key":"vol","name":"Volume","short":"Vol","kind":"f","mn":0.0,"mx":1.0,"default":0.75,"unit":null,"viz":{"kind":"fader"}},{"key":"flt_type","name":"Filter Type","short":"Type","kind":"e","mn":0,"mx":10,"default":1,"opts":["Off","LP12","LP24","HP12","BP12","BP24","Dual BP","Notch","Comb+","Comb-","Morph"],"sopts":["Off","LP12","LP24","HP12","BP12","BP24","2BP","Ntch","Cmb+","Cmb-","Mrph"]},{"key":"flt_cut","name":"Cutoff","short":"Cut","kind":"f","mn":0.0,"mx":1.0,"default":0.9,"unit":null,"viz":{"group":"flt","role":"cutoff","kind":"custom:qflt"},"live":true},{"key":"flt_res","name":"Resonance","short":"Res","kind":"f","mn":0.0,"mx":1.0,"default":0.1,"unit":null,"viz":{"group":"flt","role":"resonance","kind":"custom:qflt"}},{"key":"flt_env","name":"Filter Env","short":"FEnv","kind":"f","mn":-1.0,"mx":1.0,"default":0.0,"unit":null},{"key":"me_a","name":"Mod Env Attack","short":"Atk","kind":"f","mn":0.0,"mx":1.0,"default":0.0,"unit":null,"viz":{"group":"me","role":"attack","kind":"envelope"}},{"key":"me_d","name":"Mod Env Decay","short":"Dec","kind":"f","mn":0.0,"mx":1.0,"default":0.5,"unit":null,"viz":{"group":"me","role":"decay","kind":"envelope"}},{"key":"me_s","name":"Mod Env Sustain","short":"Sus","kind":"f","mn":0.0,"mx":1.0,"default":0.0,"unit":null,"viz":{"group":"me","role":"sustain","kind":"envelope"}},{"key":"me_r","name":"Mod Env Release","short":"Rel","kind":"f","mn":0.0,"mx":1.0,"default":0.4,"unit":null,"viz":{"group":"me","role":"release","kind":"envelope"}},{"key":"tx_drive","name":"Atmos Drive","short":"Drive","kind":"f","mn":0.0,"mx":1.0,"default":0.0,"unit":null,"viz":{"group":"drv","role":"drive","kind":"custom:qdrive"}},{"key":"tx_drvpos","name":"Drive Position","short":"DrvPs","kind":"e","mn":0,"mx":2,"default":0,"opts":["Pre Filter","Post Filter","Amp"],"sopts":["Pre","Post","Amp"],"viz":{"group":"drv","role":"position","kind":"custom:qdrive"}},{"key":"tx_dtone","name":"Drive Tone","short":"DTone","kind":"f","mn":0.0,"mx":1.0,"default":0.7,"unit":null},{"key":"tx_detune","name":"Atmos Detune","short":"Detun","kind":"f","mn":0.0,"mx":1.0,"default":0.0,"unit":null,"viz":{"group":"det","role":"detune","kind":"custom:qdet"},"card":"cards.js#quark_card"},{"key":"tx_bloom","name":"Detune Bloom","short":"Bloom","kind":"f","mn":0.0,"mx":1.0,"default":0.0,"unit":null,"viz":{"group":"det","role":"bloom","kind":"custom:qdet"},"card":"cards.js#quark_card"},{"key":"tx_spread","name":"Spread","short":"Sprd","kind":"f","mn":0.0,"mx":1.0,"default":0.3,"unit":null},{"key":"flt_key","name":"Filter Keytrack","short":"KeyTk","kind":"f","mn":0.0,"mx":1.0,"default":0.5,"unit":null},{"key":"an_shape","name":"Motion Shape","short":"Shape","kind":"e","mn":0,"mx":5,"default":0,"opts":["Sine","Tri","Saw","Square","S&H","Random Walk"],"sopts":["Sine","Tri","Saw","Sqr","S&H","Rnd"],"viz":{"group":"an","role":"shape","kind":"lfo"},"card":"cards.js#quark_card"},{"key":"an_rate","name":"Motion Rate","short":"Rate","kind":"f","mn":0.0,"mx":1.0,"default":0.35,"unit":null,"viz":{"group":"an","role":"rate","kind":"lfo"}},{"key":"an_dest","name":"Motion Target","short":"Dest","kind":"e","mn":0,"mx":14,"default":0,"opts":["Variation","Pitch","Filter","Pan","Amp","Var+Filter","Var+Pitch","Var+Pan","Var+Amp","Pitch+Filter","Pitch+Pan","Pitch+Amp","Filter+Pan","Filter+Amp","Pan+Amp"],"sopts":["Var","Ptch","Filt","Pan","Amp","V+F","V+P","V+Pn","V+A","P+F","P+Pn","P+A","F+Pn","F+A","Pn+A"],"card":"cards.js#quark_card"},{"key":"vib","name":"Vibrato","short":"Vib","kind":"f","mn":0.0,"mx":1.0,"default":0.0,"unit":null},{"key":"vib_rate","name":"Vibrato Rate","short":"VRate","kind":"f","mn":0.0,"mx":1.0,"default":0.45,"unit":null},{"key":"ens_type","name":"Ensemble Type","short":"EnsTp","kind":"e","mn":0,"mx":3,"default":0,"opts":["Strings","Chorus","Both","Deep"],"sopts":["Str","Cho","Both","Deep"]},{"key":"ln_cut","name":"Melody Cutoff","short":"Cut","kind":"f","mn":0.0,"mx":1.0,"default":0.75,"unit":null,"viz":{"group":"lf","role":"cutoff","kind":"filter"}},{"key":"ln_res","name":"Melody Resonance","short":"Res","kind":"f","mn":0.0,"mx":1.0,"default":0.15,"unit":null,"viz":{"group":"lf","role":"resonance","kind":"filter"}},{"key":"ln_fenv","name":"Melody Filter Env","short":"FEnv","kind":"f","mn":-1.0,"mx":1.0,"default":0.3,"unit":null},{"key":"ln_wenv","name":"Melody Var Env","short":"VrEnv","kind":"f","mn":-1.0,"mx":1.0,"default":0.0,"unit":null},{"key":"ln_det","name":"Melody Detune","short":"Detun","kind":"i","mn":0,"mx":50,"default":11,"unit":"ct"},{"key":"ln_int","name":"Melody Interval","short":"Intvl","kind":"i","mn":-24,"mx":24,"default":0,"unit":"st"},{"key":"ln_glide","name":"Melody Glide","short":"Glide","kind":"f","mn":0.0,"mx":1.0,"default":0.0,"unit":null},{"key":"ln_sus","name":"Melody Envelope","short":"EnvMd","kind":"e","mn":0,"mx":1,"default":1,"opts":["Trig","Sust"],"sopts":null},{"key":"arp_mode","name":"Arp Type","short":"Type","kind":"e","mn":0,"mx":10,"default":0,"opts":["Off","Up","Down","Up/Down","Down/Up","Random","Order","Chord","Leap In","Leap Out","Pattern"],"sopts":["Off","Up","Down","UpDn","DnUp","Rnd","Ord","Chrd","LpIn","LpOt","Patt"],"card":"cards.js#quark_card"},{"key":"arp_src","name":"Arp Source","short":"Src","kind":"e","mn":0,"mx":1,"default":1,"opts":["Keys","Atmos Chord"],"sopts":["Keys","Chrd"],"card":"cards.js#quark_card"},{"key":"arp_rate","name":"Arp Rate","short":"Rate","kind":"e","mn":0,"mx":6,"default":4,"opts":["1/4","1/8D","1/8","1/8T","1/16","1/16T","1/32"],"sopts":["4","8D","8","8T","16","16T","32"]},{"key":"arp_oct","name":"Arp Octaves","short":"Oct","kind":"e","mn":0,"mx":8,"default":0,"opts":["0","+1","+2","+3","-1","-2","-3","-1..+1","-2..+2"],"sopts":["0","+1","+2","+3","-1","-2","-3","+-1","+-2"],"card":"cards.js#quark_card"},{"key":"arp_gate","name":"Arp Gate","short":"Gate","kind":"f","mn":0.0,"mx":1.0,"default":0.55,"unit":null,"card":"cards.js#quark_card"},{"key":"arp_swing","name":"Arp Swing","short":"Swing","kind":"f","mn":0.0,"mx":1.0,"default":0.0,"unit":null,"card":"cards.js#quark_card"},{"key":"arp_hold","name":"Melody Latch","short":"Latch","kind":"e","mn":0,"mx":1,"default":0,"opts":["Off","On"],"sopts":null,"viz":{"kind":"switch"}},{"key":"arp_rhy","name":"Arp Rhythm","short":"Rhym","kind":"i","mn":0,"mx":39,"default":0,"unit":null,"card":"cards.js#quark_card"},{"key":"arp_pat","name":"Arp Pattern","short":"Patt","kind":"i","mn":0,"mx":39,"default":0,"unit":null,"card":"cards.js#quark_card"},{"key":"arp_drop","name":"Arp Drop","short":"Drop","kind":"f","mn":0.0,"mx":1.0,"default":0.0,"unit":null,"card":"cards.js#quark_card"},{"key":"arp_vel","name":"Arp Velocity","short":"Vel","kind":"i","mn":0,"mx":127,"default":0,"unit":null,"card":"cards.js#quark_card"},{"key":"arp_vrnd","name":"Arp Vel Random","short":"VRnd","kind":"f","mn":0.0,"mx":1.0,"default":0.0,"unit":null,"card":"cards.js#quark_card"},{"key":"arp_grnd","name":"Arp Gate Random","short":"GRnd","kind":"f","mn":0.0,"mx":1.0,"default":0.0,"unit":null,"card":"cards.js#quark_card"},{"key":"arp_ornd","name":"Arp Oct Random","short":"ORnd","kind":"f","mn":0.0,"mx":1.0,"default":0.0,"unit":null,"card":"cards.js#quark_card"},{"key":"arp_nrnd","name":"Arp Note Random","short":"NRnd","kind":"f","mn":0.0,"mx":1.0,"default":0.0,"unit":null,"card":"cards.js#quark_card"},{"key":"arp_loop","name":"Arp Var Loop","short":"Loop","kind":"i","mn":0,"mx":32,"default":0,"unit":null,"card":"cards.js#quark_card"},{"key":"fx_tone","name":"Effect Control 2","short":"Ctrl2","kind":"f","mn":0.0,"mx":1.0,"default":0.4,"unit":null,"card":"cards.js#quark_card","card_w":110,"card_h":17},{"key":"rv_size","name":"Reverb Size","short":"Size","kind":"f","mn":0.0,"mx":1.0,"default":0.6,"unit":null},{"key":"rv_tone","name":"Reverb Tone","short":"Tone","kind":"f","mn":0.0,"mx":1.0,"default":0.55,"unit":null},{"key":"tx_fx","name":"Atmos FX Route","short":"AtFX","kind":"e","mn":0,"mx":2,"default":0,"opts":["FX+Rev","Rev","Dry"],"sopts":["All","Rev","Dry"]},{"key":"ln_fx","name":"Melody FX Route","short":"MlFX","kind":"e","mn":0,"mx":2,"default":0,"opts":["FX+Rev","Rev","Dry"],"sopts":["All","Rev","Dry"]},{"key":"ln_spread","name":"Melody Spread","short":"Wide","kind":"f","mn":-1.0,"mx":1.0,"default":0.0,"unit":null},{"key":"ln_dly","name":"Melody Delay","short":"Delay","kind":"f","mn":0.0,"mx":1.0,"default":0.0,"unit":null},{"key":"ln_dtime","name":"Melody Delay Time","short":"Time","kind":"e","mn":0,"mx":11,"default":7,"opts":["1/32","1/16T","1/16","1/8T","1/16D","1/8","1/4T","1/8D","1/4","1/2T","1/4D","1/2"],"sopts":["32","16T","16","8T","16D","8","4T","8D","4","2T","4D","2"]},{"key":"tx_tr","name":"Atmos Transpose","short":"AtTr","kind":"i","mn":-24,"mx":24,"default":0,"unit":"st"},{"key":"ln_tr","name":"Melody Transpose","short":"MlTr","kind":"i","mn":-24,"mx":24,"default":0,"unit":"st"},{"key":"key_mode","name":"Key Mode","short":"Keys","kind":"e","mn":0,"mx":4,"default":0,"opts":["Stack","Melody Low","Melody High","Atmos Only","Melody Only"],"sopts":["Stk","MelL","MelH","Atmo","Melo"],"card":"cards.js#quark_card"},{"key":"split","name":"Split Point","short":"Split","kind":"i","mn":24,"mx":96,"default":60,"unit":null,"card":"cards.js#quark_card"},{"key":"vel","name":"Velocity","short":"Vel","kind":"f","mn":0.0,"mx":1.0,"default":0.5,"unit":null},{"key":"wheel","name":"Mod Wheel","short":"Wheel","kind":"e","mn":0,"mx":3,"default":0,"opts":["Vibrato","Motion","Cutoff","Variation"],"sopts":["Vib","Mot","Cut","Var"]},{"key":"ln_mode","name":"Melody Mode","short":"Mode","kind":"e","mn":0,"mx":2,"default":1,"opts":["Mono","Legato","Poly"],"sopts":["Mono","Leg","Poly"]},{"key":"tx_latch","name":"Atmos Latch","short":"Latch","kind":"e","mn":0,"mx":1,"default":0,"opts":["Off","On"],"sopts":null,"viz":{"kind":"switch"}},{"key":"an_lfo2","name":"LFO 2 Rate","short":"LFO2","kind":"f","mn":-4.0,"mx":4.0,"default":1.0,"unit":null,"card":"cards.js#quark_card"},{"key":"pcm_era","name":"PCM Era","short":"Era","kind":"e","mn":0,"mx":2,"default":0,"opts":["Clean","90s","Lo-Fi"],"sopts":["Cln","90s","Lo"],"viz":{"kind":"custom:qera"},"card":"cards.js#quark_card"},{"key":"pcm_b","name":"PCM B","short":"PCM B","kind":"e","mn":0,"mx":32,"default":0,"opts":["Off","Wine Glass","Bowed Vibes","Section Strings","Psaltery","Concert Flute","Ocarina","Organ Blower","Ocean Drum","Cymbal Bow","Gong Scrape","Hand Chimes","Soft Vibes","Glock","Kalimba","Pipe Organ","Digi E.Piano","Aah","Ooh","Sung Chord","Dream Chord","Breath Loop","Shakuhachi","Shaku Breath","Sitar","Tanpura","Dan Tranh","Duduk","Erhu","Sarangi","Koto","Singing Bowl","Didgeridoo"],"sopts":["Off","WGls","BVib","SStr","Psal","CFlt","Ocar","Blwr","Ocn","Cymb","Gong","Chim","SVib","Glck","Kalm","POrg","DEP","Aah","Ooh","SChd","Drm","BrLp","Shak","ShBr","Sitr","Tanp","DanT","Dudk","Erhu","Sarg","Koto","Bowl","Didg"],"card":"cards.js#quark_card"},{"key":"an_mode","name":"LFO Mode","short":"LFOMd","kind":"e","mn":0,"mx":2,"default":0,"opts":["Global","Spread","Retrig"],"sopts":["Glob","Sprd","Rtrg"],"card":"cards.js#quark_card"},{"key":"pl_wave","name":"PCM Layer","short":"Layer","kind":"e","mn":0,"mx":32,"default":0,"opts":["Off","Wine Glass","Bowed Vibes","Section Strings","Psaltery","Concert Flute","Ocarina","Organ Blower","Ocean Drum","Cymbal Bow","Gong Scrape","Hand Chimes","Soft Vibes","Glock","Kalimba","Pipe Organ","Digi E.Piano","Aah","Ooh","Sung Chord","Dream Chord","Breath Loop","Shakuhachi","Shaku Breath","Sitar","Tanpura","Dan Tranh","Duduk","Erhu","Sarangi","Koto","Singing Bowl","Didgeridoo"],"sopts":["Off","WGls","BVib","SStr","Psal","CFlt","Ocar","Blwr","Ocn","Cymb","Gong","Chim","SVib","Glck","Kalm","POrg","DEP","Aah","Ooh","SChd","Drm","BrLp","Shak","ShBr","Sitr","Tanp","DanT","Dudk","Erhu","Sarg","Koto","Bowl","Didg"],"viz":{"kind":"custom:qpcm"},"card":"cards.js#quark_card"},{"key":"pl_lvl","name":"Layer Level","short":"Lvl","kind":"f","mn":0.0,"mx":1.0,"default":0.5,"unit":null},{"key":"pl_tune","name":"Layer Tune","short":"Tune","kind":"i","mn":-74,"mx":74,"default":0,"unit":null,"card":"cards.js#quark_card"},{"key":"pl_start","name":"Layer Start","short":"Start","kind":"f","mn":0.0,"mx":1.0,"default":0.0,"unit":null,"viz":{"group":"pl","role":"start","kind":"custom:qpcm"}},{"key":"pl_mode","name":"Layer Mode","short":"Mode","kind":"e","mn":0,"mx":3,"default":0,"opts":["Loop","Shot","Air","Ping"],"sopts":["Loop","Shot","Air","Ping"],"viz":{"group":"pl","role":"mode","kind":"custom:qpcm"},"card":"cards.js#quark_card"}],"texTypes":[{"name":"Strings","short":"Str","family":0,"index":0},{"name":"Vintage","short":"Vint","family":0,"index":1},{"name":"Brass","short":"Bras","family":0,"index":2},{"name":"Organ","short":"Orgn","family":0,"index":3},{"name":"Choir","short":"Chor","family":0,"index":4},{"name":"Poly Saw","short":"PSaw","family":1,"index":0},{"name":"Square","short":"Sqr","family":1,"index":1},{"name":"Drawbar","short":"Draw","family":1,"index":2},{"name":"Reed","short":"Reed","family":1,"index":3},{"name":"Resonant","short":"Reso","family":1,"index":4},{"name":"Mallet","short":"Malt","family":1,"index":5},{"name":"Bellish","short":"Bell","family":1,"index":6},{"name":"Add Harm","short":"Add","family":1,"index":7},{"name":"Vocal","short":"Vox","family":1,"index":8},{"name":"Glass","short":"Glas","family":1,"index":9},{"name":"Fifths","short":"5ths","family":1,"index":10},{"name":"Minor 9","short":"Min9","family":1,"index":11},{"name":"Major 9","short":"Maj9","family":1,"index":12},{"name":"Dom 11","short":"Dm11","family":1,"index":13},{"name":"Fourths","short":"4ths","family":1,"index":14},{"name":"E.Piano","short":"EP","family":2,"index":0},{"name":"FM Bells","short":"FMBl","family":2,"index":1},{"name":"FM Keys","short":"Keys","family":2,"index":2},{"name":"FM Glass","short":"FMGl","family":2,"index":3},{"name":"Metal","short":"Metl","family":2,"index":4},{"name":"FM Pad","short":"FMPd","family":2,"index":5},{"name":"Basic","short":"Basi","family":1,"index":15},{"name":"Pulse","short":"Puls","family":1,"index":16},{"name":"Resonant WT","short":"RsWT","family":1,"index":17},{"name":"Resonant 2","short":"Res2","family":1,"index":18},{"name":"Sync","short":"Sync","family":1,"index":19},{"name":"Formant A","short":"Frmn","family":1,"index":20},{"name":"Formant B","short":"Form","family":1,"index":21},{"name":"Harmonic","short":"Hrmn","family":1,"index":22},{"name":"Odd","short":"Odd","family":1,"index":23},{"name":"Bell","short":"Blll","family":1,"index":24},{"name":"Organ WT","short":"OrWT","family":1,"index":25},{"name":"Digital","short":"Dgtl","family":1,"index":26},{"name":"Noise","short":"Nois","family":1,"index":27},{"name":"PWM Saw","short":"PWMS","family":1,"index":28},{"name":"Fold","short":"Fold","family":1,"index":29},{"name":"Steps","short":"Stps","family":1,"index":30},{"name":"Strings WT","short":"StWT","family":1,"index":31},{"name":"Brass WT","short":"BrWT","family":1,"index":32},{"name":"Bass Spectra","short":"BssS","family":1,"index":33},{"name":"Choir WT","short":"ChWT","family":1,"index":34},{"name":"Glass WT","short":"GlWT","family":1,"index":35},{"name":"Chaos","short":"Chao","family":1,"index":36},{"name":"Comb","short":"Comb","family":1,"index":37},{"name":"PhaseDist","short":"PhsD","family":1,"index":38},{"name":"Fractal","short":"Frct","family":1,"index":39},{"name":"Upper","short":"Uppr","family":1,"index":40},{"name":"Clav","short":"Clav","family":1,"index":41},{"name":"Breath","short":"Brth","family":1,"index":42},{"name":"SqSync","short":"SqSy","family":1,"index":43},{"name":"Metal WT","short":"MtWT","family":1,"index":44},{"name":"Stack","short":"Stck","family":1,"index":45},{"name":"Granite","short":"Grnt","family":1,"index":46},{"name":"Cello","short":"Cell","family":1,"index":47},{"name":"Violin","short":"Viol","family":1,"index":48},{"name":"Voice","short":"Voic","family":1,"index":49},{"name":"EPiano","short":"EPia","family":1,"index":50},{"name":"Clavinet","short":"Clvn","family":1,"index":51},{"name":"E-Organ","short":"Ergn","family":1,"index":52},{"name":"FM","short":"FM","family":1,"index":53},{"name":"Chip","short":"Chip","family":1,"index":54},{"name":"VGame","short":"VGam","family":1,"index":55},{"name":"Sax","short":"Sax","family":1,"index":56},{"name":"Flute","short":"Flut","family":1,"index":57},{"name":"Overtone","short":"Ovrt","family":1,"index":58},{"name":"Crushed","short":"Crsh","family":1,"index":59},{"name":"Granular","short":"Grnl","family":1,"index":60},{"name":"Upright","short":"Uprg","family":1,"index":61},{"name":"Piano","short":"Pian","family":1,"index":62},{"name":"Even","short":"Even","family":1,"index":63},{"name":"Partials","short":"Prtl","family":1,"index":64},{"name":"Feedback","short":"Fdbc","family":1,"index":65},{"name":"Window","short":"Wndw","family":1,"index":66},{"name":"Rave","short":"Rave","family":1,"index":67},{"name":"Octaves","short":"Octv","family":1,"index":68},{"name":"Logic","short":"Logi","family":1,"index":69},{"name":"Reed WT","short":"RdWT","family":1,"index":70},{"name":"Pluck","short":"Plck","family":1,"index":71},{"name":"Sweep","short":"Swee","family":1,"index":72},{"name":"Chord","short":"Chrd","family":1,"index":73},{"name":"Vosim","short":"Vosi","family":1,"index":74},{"name":"Scanned","short":"Scnn","family":1,"index":75},{"name":"Prime","short":"Prim","family":1,"index":76},{"name":"SineSync","short":"SnSy","family":1,"index":77},{"name":"Mallet WT","short":"MlWT","family":1,"index":78},{"name":"Mixer","short":"Mixe","family":1,"index":79},{"name":"Sub","short":"Sub","family":1,"index":80},{"name":"Notch","short":"Ntch","family":1,"index":81},{"name":"Drive","short":"Driv","family":1,"index":82},{"name":"E-Bass","short":"EBss","family":1,"index":83},{"name":"E-Guitar","short":"EGtr","family":1,"index":84},{"name":"Distorted","short":"Dstr","family":1,"index":85},{"name":"Theremin","short":"Thrm","family":1,"index":86},{"name":"Raw","short":"Raw","family":1,"index":87},{"name":"Drawn","short":"Drwn","family":1,"index":88},{"name":"Wine Glass","short":"WGls","family":3,"index":0},{"name":"Bowed Vibes","short":"BVib","family":3,"index":1},{"name":"Section Strings","short":"SStr","family":3,"index":2},{"name":"Psaltery","short":"Psal","family":3,"index":3},{"name":"Concert Flute","short":"CFlt","family":3,"index":4},{"name":"Ocarina","short":"Ocar","family":3,"index":5},{"name":"Organ Blower","short":"Blwr","family":3,"index":6},{"name":"Ocean Drum","short":"Ocn","family":3,"index":7},{"name":"Cymbal Bow","short":"Cymb","family":3,"index":8},{"name":"Gong Scrape","short":"Gong","family":3,"index":9},{"name":"Hand Chimes","short":"Chim","family":3,"index":10},{"name":"Soft Vibes","short":"SVib","family":3,"index":11},{"name":"Glock","short":"Glck","family":3,"index":12},{"name":"Kalimba","short":"Kalm","family":3,"index":13},{"name":"Pipe Organ","short":"POrg","family":3,"index":14},{"name":"Digi E.Piano","short":"DEP","family":3,"index":15},{"name":"Aah","short":"Aah","family":3,"index":16},{"name":"Ooh","short":"Ooh","family":3,"index":17},{"name":"Sung Chord","short":"SChd","family":3,"index":18},{"name":"Dream Chord","short":"Drm","family":3,"index":19},{"name":"Breath Loop","short":"BrLp","family":3,"index":20},{"name":"Shakuhachi","short":"Shak","family":3,"index":21},{"name":"Shaku Breath","short":"ShBr","family":3,"index":22},{"name":"Sitar","short":"Sitr","family":3,"index":23},{"name":"Tanpura","short":"Tanp","family":3,"index":24},{"name":"Dan Tranh","short":"DanT","family":3,"index":25},{"name":"Duduk","short":"Dudk","family":3,"index":26},{"name":"Erhu","short":"Erhu","family":3,"index":27},{"name":"Sarangi","short":"Sarg","family":3,"index":28},{"name":"Koto","short":"Koto","family":3,"index":29},{"name":"Singing Bowl","short":"Bowl","family":3,"index":30},{"name":"Didgeridoo","short":"Didg","family":3,"index":31},{"name":"User 1","short":"U1","family":1,"index":89},{"name":"User 2","short":"U2","family":1,"index":90},{"name":"User 3","short":"U3","family":1,"index":91},{"name":"User 4","short":"U4","family":1,"index":92},{"name":"User 5","short":"U5","family":1,"index":93},{"name":"User 6","short":"U6","family":1,"index":94},{"name":"User 7","short":"U7","family":1,"index":95},{"name":"User 8","short":"U8","family":1,"index":96},{"name":"User 9","short":"U9","family":1,"index":97},{"name":"User 10","short":"U10","family":1,"index":98},{"name":"User 11","short":"U11","family":1,"index":99},{"name":"User 12","short":"U12","family":1,"index":100},{"name":"User 13","short":"U13","family":1,"index":101},{"name":"User 14","short":"U14","family":1,"index":102},{"name":"User 15","short":"U15","family":1,"index":103},{"name":"User 16","short":"U16","family":1,"index":104}],"regFields":["s16","s8","s4","q16","q8","q4","q2","bright","form","vowel","swell"],"strings":[[[0,1.0,0.55,0,0,0,0,56,0.22,0.62,0],[0.25,1.0,0.25,0,0,0,0,46,0.18,0.5,0],[0.95,0.7,0,0,0,0,0,34,0.14,0.3,0],[0.45,1.0,0.1,0,0,0,0,16,0,0.5,40],[0,0,0,0.55,0.8,0.5,0.3,64,0,0.5,0],[0.2,0.7,0,0,0.35,0,0,42,1.0,0.5,0]],[[0.7,0.8,0,0,0,0,0,26,0.1,0.3,0],[0.3,1.0,0.35,0,0,0,0,40,0.12,0.5,0],[0,1.0,0.6,0,0,0,0.25,60,0.1,0.7,0]],[[0.5,1.0,0,0,0,0,0,8,0,0.5,30],[0.3,1.0,0.2,0,0,0,0,18,0,0.5,44],[0,1.0,0.45,0,0,0.15,0,30,0,0.5,50]],[[0,0,0,0.8,1.0,0,0,60,0,0.5,0],[0,0,0,0.5,0.85,0.65,0.25,64,0,0.5,0],[0,0,0,0.65,0.8,0.7,0.65,70,0,0.5,0],[0,0.35,0,0,0.6,0.8,0.8,72,0,0.5,0]],[[0.25,0.6,0,0,0.4,0,0,38,1.0,0.0,0],[0.25,0.6,0,0,0.4,0,0,40,1.0,0.25,0],[0.25,0.6,0,0,0.4,0,0,42,1.0,0.5,0],[0.25,0.6,0,0,0.4,0,0,44,1.0,0.75,0],[0.25,0.6,0,0,0.4,0,0,46,1.0,1.0,0]]],"fm":[[1.0,2.2,14.0,1.1,0.3,0.0],[3.5,3.2,7.13,0.6,2.2,0.0],[2.0,3.0,3.0,0.5,0.18,0.25],[5.0,1.6,9.0,0.35,1.2,0.0],[1.414,4.0,2.83,1.0,0.9,0.35],[1.003,2.4,0.5,0.45,0.0,0.12]],"wt":["AHh3aFtVUkk+NjEpHxYQCgD28Orh18/Kwreuq6WYiYgAeHZnWVJNRDgvKSEWDAX+AAL79Orf19HIvLOup5mKiAB4dmZXT0pAMykjGg8E+/QADAX88ebd183AtrGpmoqIAHh1ZVVNRz0wJR0VCf3z7AAUDQP36+Pb0MO5s6ubi4gAeHVkVEtFOiwhGRAE9+zlABsUCfzw59/Uxru1rJyLiAB4dWNSSUI4KR0VDP/x5t8AIRoPAfTr49fIvreunYuIAHh0Y1FIQTUnGhEI++3h2QAnHxMF+O/m2cu/uK+djIgAeHRiUEY/MyQXDgX46dzVACskFwj78unczcG6sJ6MiA==","bXB0cGxweHMAjYiQlJCMkJOQjJCUkIiNAHN4cGxwdHB0c3BwdHhyC6ihpaqqpqWoqqilpqqqpaGoC3J4dHBwc3VxbXF4dBO7t7y/vLq8vry7vL68ury/vLe7E3R4cW1xcnN1eHQczcbKz87Kyc3Oy8nLzs3Jys7PysbNHHR4dXNscXh0INrW2tzb2drb29ra29ra29va2dvc2tbaIHR4cXZ4dynm4OPo5+Pj5ufl4+Xn5ePl5+bj4+fo4+DmKXd4eHIn8e7w8fHw8PHx8PDw8PDw8PDw8fHw8PHx8O7xJ3J4M/rz9/z69/f6+vj3+fr49/j6+ff4+vr39/r89/P6Mw==","ABcuQ1Vkb3Z4dm9kVUMuFwDp0r2rnJGKiIqRnKu90ukAJERecHh3bV1JNSITCQMAAAD99+3ey7ejk4mIkKK83AAyW3N4a1Q5IhQQExkbGA4A8ujl5+3w7N7HrJWIjaXOAEZzeFotCP0OL09fWkYsFADs1LqmobHR8gP406aIjboAUHhwUDUlGAsHEh8a/+TkABwcAebh7vn16NvLsJCIsABmeFVDPSABAAoIDyYd6dIALhfj2vH49gD/4MO9q4iaAHhb/e0PBvceRTIkPiW8lABsRNvC3M674gn68RMDpYgAeFUvIRARBxAS/AAKHwfHADn54fYABO7w+e/w39GriA==","AC5IWWZvdXh4dnFpX1FAKADYwK+hl4+KiIiLkZqnuNIANlBfanJ3eHd0b2heUUEqANa/r6KYkYyJiImOlqGwygBBWWdvdXh4dnJtZlxQQi0A076wpJqTjoqIiIuRmae/AE5kbnN3eHZybmliWE5CLwDRvrKonpeSjoqIiY2SnLIAYHJ2d3h4dG5qZV1US0EyAM6/tayjm5aSjIiIiYqOoABueHRwb25oYVxYUUhBOzAA0MW/uK+opJ+YkpGQjIiSAHZ4bGJgXldOSkdBOTMyKwDVzs3Hv7m2sqmioJ6UiIoAeHJeT01MRDo3NjEpJSYkANza29fPysnGvLSzsaKOiA==","AC9Wb3hxWzsW8NC6sLXF4AAgO0tQRjAQ6sWlj4iRqtEATXh4Vyj+6esAGS00LyIRAO/e0czT5wAVFwLYqYiIswB4diTsBEJYMwP2DSIbBvoABvrl3vMK/c2ovvwU3IqIAHgLD1klBS4nDRMXDggHBQD7+fjy6e3z2dL726fx9YgAaXhPXktJQzgzKyUdFQ8IAPjx6+Pb1c3Ivbe1orGIlwBheHRQSFVONy0yLhwPEQ8A8e/x5NLO08myq7iwjIifAHh3aFtVUUk+NjApHxYQCgD28Orh19DKwrevq6WYiYgAeHdoW1VSST42MSkfFhAKAPbw6uHXz8rCt66rpZiJiA==","ACxKVVBGRE1hc3hrUDAWBwD56tCwlYiNn7O8urCrttQAM0dPTzoyR1tqeGtFJg79AAPy2ruViJaluc7GsbG5zQA4REtOLyNCV2N4azwdCPYACvjjxJWInam+3dGytbzIADxBSE0lFj5TXHhrNBUC8AAQ/uvMlYikrcLq27O4v8QAQD9FTBwLO1BWeGstDf3sABQD89OViKqwxfXktLvBwABCPUNLFAE5TVB4bCcG+egAGAf62ZSIsLPH/+y1vcO+AEQ7QkoM+TdKS3htIQD15QAbCwDfk4i1tskH9La+xbwARjlBSgXxNkhGeG8d+vLjAB0OBuORiLq4yg/7tr/Hug==","ADdRSDUzTW54XjANCyIzJwDZzd7189CiiJKzzcu4r8kASmFVQzxceHVkNwwPJj03AMnD2vH0yZyLiKTEvauftgBabF1NP2Z4amI8CRInQkQAvL7Z7vfEnpaImsGzo5SmAG13Z1hEc3hgXkMFFShIUwCtuNjr+72ioIiNvKiZiZMAdnhoXEF3bE5RRQEWJ0dcAKS52er/u6+ylIm/pJiIigB4cWNaO3RaPUBE/RYkQV4Aor/c6gO8wMOmjMWmnY+IAHhqXlc1cUkvMEP5FSE8XwChxN/rB73Q0bePy6milogAeGRaVDBvOiQiQvUVIDdgAKDJ4OsLvt7cxpHQrKaciA==","ADJYb3h4cmlfU0g8MCQYDAD06NzQxLitoZeOiIiRqM4APGZ3eHBlWU5EOjAmHBMJAPft5NrQxryyp5uQiImaxABweFlPSkI6My0mHxkTDAYA+vTt5+Ha083Gvraxp4iQAHhaTEg/OTMsJyEbFhALBQD79fDq5d/Z1M3Hwbi0pogAeHFcS0ZEOzAqJyEYEA0IAPjz8Ojf2dbQxby6taSPiAB4cVxLRkQ7MConIRgQDQgA+PPw6N/Z1tDFvLq1pI+IAHhxXEtGRDswKichGBANCAD48/Do39nW0MW8urWkj4gAeHFcS0ZEOzAqJyEYEA0IAPjz8Ojf2dbQxby6taSPiA==","AG5teCU+SFQ//Ne+xtPh8AAQHy06QikEway4wtuIk5IAcnhxBgPl+ufS0OILJi4dAOPS2vUeMC4ZBhv9+o+IjgB1eFTZzrv1+wwKEhMJ//oABgH37e729AULRTInrIiLAHhnKLrU2Qf7FiYqCeHP3QAjMR/31trqBfknLEbYmYgAeEcS7Aq5wvdIORb66NTZACcsGAbqx7gJPkf2FO65iAB4KGFK6bXoqOQYGyIsFAkA9+zU3uXoHFgYSxe2n9iIAE0qeE4gNdHkzcbq7v8OAwD98gESFjozHC/L4LKI1rMAMTxuV3hVUDUTDOft3evxAA8VIxMZ9O3LsKuIqZLEzw==","ABs1TF9tdXh2b2RXRzclEgDu28m5qZyRioiLk6G0y+UAKz1TYmx4cXh2X1NKQDQTAO3MwLatoYqIj4iUnq3D1QA4Q1hjZ3hmd3hXTUtGQxQA7L26tbOpiImaiJmdqL3IAERJXGNfeFp3d09GTEpQFQDrsLa0urGJiaaIoZ2kt7wATk5fZFZ4TnZ0SD5NTF0WAOqjtLPCuIyKsoiqnKGysgBVU2JkS3hBdm5CN05NaRgA6Jezssm+koq/iLWcnq2rAFtXZGU/eDV2Zz0wT0t0GgDmjLWx0MOZisuIwZucqaUAW1dhYC9yKHBZNidNRXgbAOWIu7PZyqeQ2I7RoJ+ppQ==","AHhVR0ElIwwA9N3bv7mriAB4VUdBJSMMAPTd27+5q4jvPBz1KVpCJRT448y0nYjAPnhcQDAT/uzG0hgY7ObGpwc9GesRIy9FJQbrybKIlvJHbk4pF+n3FuXmFgjfxMne5Ug27Q4CJmUsBdWz0Z+a5yN4aSkTyfA47uf+7/3Zy9TrTTzs/BhRbiX5wo/A0rfCEnhWHzsUBBXPttkGNxDKnfEuMQUA/0R4JePFsszBu+AUVEgxOPv/Kdmo2hw1982/9ioDAjAYAwYaJgHswoi5CzpIKygO3PwF8BUd8cPI+//0KgQKFOrt7Cd4RR0a//nu//Kw5QvS6BAjJPLZvcUNBQ==","7TAa/C5dSCsW+N/Eq5WIxz11Ykg1F/3pxtMSFO3jxa8MNxgJ7vcfARE4GQjs0sKfz/HkQ3hORCYL+NLIoqLSxeodLiL/Axb1/Q0FIAzp2bHO5MomeFpEKAfuzLSkzvjf7RYXDAUXHvj7/fAcH/rgusnTzTN4UToa8efi0bbU89D0GhEBIiH9/QwcIffQs4i8RHFHJQTv+vTe7RAYBe7j2/0mGAnzCi4H/freEC8I4ri3yN9BeE0nDwP15M2jzAbd/TUR6SU7APAPMTHsq5CI1EpqWjjv4x0Ny870ES0X0LXwEBon9MghVBv5H3V4LA/aora81hwQ0eA4ReKdoNgXHQ==","7zwc9SlaQiUU+OPMtJ2IwD54XEAwE/7sxtIYGOzmxqcJQx8A7gYq+Qo+FgHqybiTvv0VZnNDPhcA8MTAlojWA+MoOhn9DRrv7xAeJf7fx5292wByeEE7C/XcrdXPsOoF5yAgAgQiIPLw/QUkFfDQqrjKAXh0OTL94N7O6ti74u3yIxP0HiQCERMGEfrWtYjASnRIJgfZy/wbDBcGyd340gMsEfAHJhQREPQJDuC9iLZSdUEd8+Li/hf5DhnU4O3G8iwc8/4rKe3i/BMpCOPZwsPB9nZ4Mh748O7M3dvR7eT3FRsYD9veNEktIBxKYRLXv4inJjfv6/no/Ajk2//1vw==","7jUb+StbRSgV+OHIsJmIxD12X0QyFf3qxtMVFuzlxasKPx8B8Aco/A08FwDox7WUvfoXZnVJQRoA7sK6kojVBuYhNBwADxry+AsGHgnh0arC6e9FeFA9HPrnvqmpxvcQ6RocBgcjIfT3+vEfHvHXsrvW8lN4SDUM5efawrXM7fjoGx0EDjIj7fb16x8Y69Shv/4FSXhHKgfa2dSwrvwg9/QdEf0gIPwADhke9tK3iL5Mbz8k/+j/+OD2EQwA8+nb6CQtFO8DMhYD7MwURAfHnq3WAld4WDP34/Xrx5GpAhzzExMY/9kHOjIJ80F4MPTm0rOw+yP29AoB/fvpxc8IEA==","yhgUASJPcm0p8+OxiZ+biOBacmFqbF0rypOblJ7h+ej1NSLj9xosVEISEN2Pm5yI8GVraV4uIQG3ut/P3/7dz+EuNAEABgs4QSol4oiOoKgOaVZBOiYxG8u1yMPqGPrY6hMbChcL9R0/OibUiKfGvvpETU07DxUb6szBuO8rB9DrExgGFhH8GDE1MOOIl7/OD0IzOkYrGwDR1uTK2AcI9vQmD/UkJPEIQUsqz4ifrrgcWi0uV0AT79jk17TfGf7j8igQ/S4Z3xphShbLiJKluA5HSGpXAQsz8a2uwO8cCt7dDCT/5gksFN7pQXhpWzvhp7rLvLHPGjX9+ScF1uzo0A==","CSI5TmBueH5+enFkUz4oEPfex7KgkoiCgoaPnK3C2PAIHDBCU2JwenxyZldGNCAM+OTQvq2ekIaEjpqpuszg9AYYKDlJWWh3emxdTT0sHAv66NjHt6eYiYaUo7PD1OT1LkNNVl9ocXp6alpKOioaCvrq2sq6qpqKhI2Wn6ixusJUaWdlYmBeXFZLQDQpHhIH/PDl2s7DuK2koqCenJmXklRkXlhSTEY/ODIsJiAZEw337uji3NbPycO8trCqpJ2UVGZiXlpWUk5JRUE9ODQwLd7RzcjEwLy4tLCrp6OempNVa2xsbGxsbGxsbGxsbGxuq5WUlJSUlJSUlJSUlJSUkg==","bGxsbGxsbG6rlZSUlJSUlJSUlJSUlJSSVWtsbGxsbGx2dnZ2d3ZxqKenqKioqKioqKioqKioqKenPXd3dnZ2dnR0dHR0bLy+vr6+vr6+vr6+vr6+vr6+vr6+PHR0dHR0enp6eljMzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OKnp6enp+fn9a2tra29vb29vb29va2tvb29vb29vb29rbMH9/fnJyPezr6+vq6+vr6+vr6+vr6+vr6+vr6+rq6+vrH3JydD/19PT09PT09PT09PT09PT09PT09PT09PT09PT0InMz/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+Eg==","JFNwfnpsV0IwIxoTDgoGAv769vLu6ODUwq6ZiIKLpMpSbRT+PUgZDCAiEw0OCwYC//z28vPw4t3w8MK49P2lj1syOk8bSCArJhoeExIMBwP++vbv7uXk4dDlvNrGsOGNUjZNQjBAKC4mHx4WEg0IA/759PDq5OPY2dPE1bTGu6JITj49QTouKigjHBcTDggD/vn07+rk3tzYzsbHyLutrkJPSkQ+OTMuKCMeGBMOCQP++fTu6eTe2NPOyMK+uLOtQlFOSEE6NC4qJSAaFA4JA/748+7o4tzX0szIw722rqZGWUtHRjw2MywmIRoUDwoE/vjy7efh2tbQyMbAtLSxoA==","KGN8dlw9Jx0dJjhQZ3BhONuokZWqw9bi5NzKrJCCk8NQR+Y2SwcjOh4iJS0yDChMx8j41s7b3OTM0PzItRPak1gAXQhTE0gePig0Myg+H0bF5L/cyNLSydy/5rTyp/2eQTIbOUIqKDs3KjE7Lio7N83Q2MjI1s/E0NrGwNzbuMUsODc1MjAwLzAxMjQ0NDMz1szMztDQ0M/OzMvJycrNzyY5PTozLzA0Nzg2MjIzNzrYysjKzs/NysfIzdLSzcXBLkcqPEIuPT4yPTwzPjozQNPCzcbDzcTDz8HD07zE1rY5Lk0uSTVAPjlBOT88PT0+z8XDwsXBxMW/y7jQts2/vw==","ppyjqrC3vsXM09rg5+71/AMKERgeJSwzOkFITlZcZGyaqLbE0uDu/AoYJzVDUWAuoK68ytjm9AIQHiw6SFZk5aquw9fsARYqP1RKnLTI3fIHHDBFWhKmus7j+AwhNktimrjU8A0qRmKkutbyDytIXp+72PQRLUlVnr3a9hMvS0mrvuIGKk8Rr9L2Gj5ipcLmCi5S/LLW+h5CVKDG6g4yWaLI8x9L/LnmET04qtcEMF6vyvYhTPG75xRAKK7ZBTJesNIENyez5hhK58b5LFio2w5BBb3vIle+0QM2OLDlGEyy3BlZstwZWbLcGVmy3BlZstwZWbLcGVmy3BlZstwZWQ==","VG8cAhMhKxr+CR0QAAUHAgD6+QH24/ED7tfb6PzzooxWdFEV9RAkNBkJAQkSCgf+Avv28PIA+e7P1usE/LqTi0t2cDUM9AMYKCUWCf8AAQL+AP8C+u/c2OH6CP7XnYWaNWp8a0Yh/urp8gYZJCceDPnm2trj9gkWGAjqxJuHjLY3aHxkRRv+7Oz4CBkiIxkM+ere3uP0BBMUCe3HooeQs0h5TCID9AgqLRYC+f0MFQz46/EABwHw2NHuCgLnwI2aQ3teMRL98wAcLCIQAvbv9gYRDAL04tXe+QwI9NivhqA9eHZoWj0S+vj8/gcWGhAF/vLn5/UBBAcI9s6rmo+EqA==","P3l1Zlg+GQL+/gAGDxIMBP727+/3/wECAO7MrZyQg6VBemxHLRoE9/oKFRYRDQwG/Pbz8Ozq8wIKAOvYwJ6EokJ6aTMN/PwEEBwhGAb17/cGEA7/7ODh7fkDBPrYpISiRHxnLAX3AQoWHSAWBPTu9gYRDwDu4uLo8v0IAOKnhJ5IfmYqBPwEDhcfHhQC9vP6BAwMAfHj4Obw+QT/5KiDmEh9ZjAL/vT9Ei0wGPrq7vgEEBYM79TQ5wAMBvrcpoSZSnxuVD4f9/H+CxAWHhoMAv/26uLo7/T+DA/rybGYhpZKfHx9ZjkTAPbwABAXGxcM+evm6O78Dg4C9NKkhoKFlw==","CSI5TmBueH5+enFkUz4oEPfex7KgkoiCgoaPnK3C2PAkbHtaMiIoLicYEBESDAQAAP327+/w69zS1d7VsYqKxjd4RCg2KBogGhATDwcJBv8B/Pb59Ozw6uDm3srVyY6rSF4tNR8lGBoSEg4MCQYEAQD8+vj09O7v5une4NLPtphPQjYiJBsYFhAQDAoIBQQB//37+Pf08vDq6+Tg3szMllI2LSYdGBYUDw0MCgYEBAH//vz69/b08O7s6eLd2s6cTzQmHxsYFBEODAoIBgUDAf/+/Pr49vTy8O3q5+LbzqRONCYfGhYTEA4MCggGBAMBAP78+vj29fLw7urm4tvPpw==","CSI5TmBueH5+enFkUz4oEPfex7KgkoiCgoaPnK3C2PA2elZGUklCSElDRlJJTXZUyoaquq63vri3vbqut7OKrE1UTD9BPDs7Ozo9Pj9LSWmzrLTBv8TFxcXGw8LBtbeXUUg/Ojg2NjU1NTU3Oj5IYq+4wcbIysrLy8vLycbCuJ5RSkE8ODY1NDQ1Njg7QEljr7a/xMjKy8zMy8rIxcC3nUhGODYyMDAuLy4wMTQ4P124usjKztDQ0tHS0M/MyMGjRD42MC4tLCsrLCwuMDM6VrzCytDS09TV1dTU0tDNxqpEOzMvLCsqKioqKywuMjlSvMXN0dTV1tbW1tXU0s7Hrg==","EkBkeX53ZlI9KhsPCAMBAAAA/vrz6NrIs56MgoSVteI/X+ujioS4JDvblYaCnw1B0tZMfHtyPdfIL3Z6ZS66oj50LP0OHAoTHCQq3r3rEgz47Ag8NOLW5On36OoE5pqiNXtvbG9QGQMVQFoc0rS64BNATjr6rrTj+/G9lZKUhK5LtYYO5eLN0AS0+7A+taMp0E1Z2yseKzT6Tw480GxqtlDu/yq+jvjJzezEq1fC3/AOFE6xLloAQi8IZFT04CumTmtd/r7bXRHlUSYwZO6HmkZ+N6q66KwAEpgNPCKwmJX9lv1Z/L7f29b5Kv2e+BYYB6oIZAL+FB0oBj8KwA02IQ==","CSI5TmBueH5+enFkUz4oEPfex7KgkoiCgoaPnK3C2PAWTHF+c1YxEPr2/g4cIh0N+Obe4e7+Cgj32LOTgomo2xlTd3xnQyAIAAUQGx8cFAj77+Xh4+z4APzoxqGHhaHXHF18dE0f//kIITEyJBIEAAD+8uHRzdryBQXrv5SCmNIgS3hkUhsM9A4SMCUsDhH7BvH12NzO6e4L+O64ooeq0EBjdi5QHBfgHgYhBUD/7MgrHBDB9OD82xzy7bDVlZumUhkSLEL4SwRB/0cYExorqEj22+j4rwO//Lj+zs3fAphLUjArMQch7RTzFgwVEPKsPify6PniEOoS5vbY08/BmA==","Bh82S15sd35+e3JmVUErE/rhyrWilImCgoWOmqu/1e0PSVhocHd9fnx3bWFTPywWAunWwq6gk4qCgYKGjZqjrxlwdXl6fHh0bmZdUEQyJBIC7t7NvrChmpCMhISChIaI/3ttamNeWFJKQzgyKBwUCf/17+HZ0sbBtq6poZiUjo//WHFqZF5WUEg8NCciGxQG//rz5uDYzsS+t7CppJaIgf4de3BqX1ROQzgyKCgkGhAM/vfw4tvUxsC5q6Sdj4iB//8+fX1kZFhLSzExJBgY//////nm5tPNxrOzoJqUgYEAAAAAAAAAAH9/f39/f39/AAAAAAAAAACBgYGBgYGBgQ==","+uTQvrSuqqiopqKhqrrM3/EEFyo8TV5rdn59cVtBKhL24tC8t7Sys7ayqaOsvc/i8gQTJDVEV2NwfH1yVzokDfPh0bq7vLu/xsKypK7B0+fyBA4eLjpOWWh5fXJSMR0I8eLWtsPIx8/e2MClscrb8PIGCRQjK0JHWHJ4cUghFALy5uG10djU4PXu0qi51+T88goDDBkaNDBDY2hqOQ0M/vbs9bXm7OHuCwPsr8fq7ArwEv4CDgYmFChOSlom9gX7/PIHuvn66PYUCgS82PjxEu0Y/PwH+Rz+EzkmRRjqAfwC+BLNBwLw+hAFF9TrAfUS7Rr9+wH1FPAHIwAnEOr//w==","ppyjqrC3vsXM09rg5+71/AMKERgeJSwzOkFITlZcZGyXlZ2lrbS9xc3V3eXt9f0FDRQcJCw0PERMVF1kbVD9BpmYoKixucLK0tvk7PT9Bg4XHygwOEFKUltjbDv1/QYQmpiiq7S9xtDa4uz1/ggRGiQtNkBJUlxlbwLs9f4IERydm6SvucPN1+Hr9f8KFB4oMjxGUFpkbtzh6/YAChQeKp+dqLO+ytXg6/YCDBgjLjlEUFtmMsrV4Ov2AgwYIy47o6CsuMXR3ur2Ag4bJzNATFhlFLnF0t7q9gIOGyc0QE6npLLAztzq+AYUIjA+TFpqp6SywM7c6vgGFCIwPkxaag==","CyhCV2h0en5/fHZrXEguEvXYvqmYjIaCgYSKlaS40u4WSm5+fHFkXFtibnp+dFQk6raSgoSPnKSlnpKGgoys3CBlfWc4B+TRz978K1x8cDTgm4OZyPkcLzEiBNWkhJDMK3dkEL2PgoKDgomu+VJ7RdWJnPBDcX5+fX53Ugeuhbs0eDC6hJjE4ubNooSkEXJRzIjQRnxoPB4aM158XO+Orz1r6Ii2GFlxc2IszojEVVzDlRh4Suinj42e1DJ4PKukQ1Wynh90dmBccHs9uZcwYr2rTmLhjIqgpJCFw0dp0J5JMpLwclL5xcDnPHgckgFmt85uEI6uBztAGcSI5G7/mg==","f39/f39/f39/f39/f39/f4GBgYGBgYGBgYGBgYGBgYFAQEBAQGB/f39/b0BAQEBAwcHBwcGhgYGBgZHAwMDAwCcnJ1dnZ3N/f3lnZ2cnJyfZ2dmpmZmNgYGHmZmZ2dnZGho/S1xudn9+eXJfXzQ0AADZzKyhlIeEgYWRmrW15eUVHzxMXW53f317bmpOPCkKANfOspyVhIOBhouiqsPX6xEhOE5mbnh/f3pyZk5AKRHv38iympKIgYGGjpqywNfvDiM3T15veX9/enJjVD4qDvLdybGikYeBgYaOnazC1vINJTxRY3F6f396cWNRPCUN89vEr52PhoGBho+dr8Tb8w==","PVBXbldHPTUuJyEbFQ8JBP748uzm4NrUzMW7rpOmrrAzUV50Y1RKQjoyKiIbEwwF/fbu59/Y0MjAuK6ijJ6suixQYndsX1ZMRDsyKSAYDgb99Ovi2dDHv7ato5iImavCJU5leXRqYVhORTsxJhwRB/zx59zSyL60qqGZj4aWq8ogTGZ6eXJqYlhOQzgsIBQI/O/i1szAtaqhmJCJhJWt0BxJZXp9eHJqYVZLPjIkFgn67d/SxLisopiQiYSDla/VGUZkeX99eHFoXlJENigZCvrr3M2/sqaakYmEgYSWstkWQV92fn98dm1iVkk6KxsK+unZyrutoJaMhoKCh5q23g==","FENmeH98dWtgVUo+MiUYCfrs3tLGuq6il42FgYWUs+AweHpoVkg9MywmIBwYFBAI+/Lt6ubh3NbPxruunIqEtkJ7ZEw8MSgiHBgVEhAODQj69PLx7+zo5ODa0se4o4mfTnBOOSwjHRgUEQ8NCwoKCfr29vX08u/s6OTe1su4mpNUZEIvJBwYFBAODAoJCAkJ+vf49/b08vDu6uXe1MSnjlZWNiYdFxMQDQwKCAcHCAn6+Pn5+Pf18/Hu6uTcz7SQV04vIRkUEA4MCggHBgYGCPr5+vr5+Pf18/Dt6OHVvZFZRyoeFhIODAoICAYGBQYI+vr7+vr5+Pb08u/r5drDkQ==","GEZld358cmZWSDouIxkPBvzz6uDUyLytnpCGgYaWsdobUXJ+eGdSPi4kHhgUEAoE/vfy7Ojk3tXHtJ6Lgoml1R9de3lgQCYYFRgbGxgSDAT99vDq5uXo6unex6iMgpjOJGp8YTIQBxIiKikiGRAKBP748urg2NXb6vj02KqHjMYqdHM+CfwSLzs0JhoTDgoE/vfy7ujez8XM5gH+0peGvTB5XBLxDjxKOCIYGBcTCwT+9+/q6Ojizri85Q38toW1NXpB8/g4Vz8fGCAiGhAKBP748ujg3ublyqu7+hXWiq06dR7jHl5JHBgrLB4UEAwF/fbx7ubY0+PqxKDMF/uYpw==","Qn54ViQEAAIECAQLGB8dEPbk4Oby+/n6//8A5raNgqA5dH5qPA/05OT1BRkpKyIR9uHW1eL2BxgeEPrQoISHrDl0fm1DGAL2+ggOEhEKBAP+/Pjw7fD1AgsC8Mmcg4isMmp8eGBAKxkLA/fr4+Dm9gYXIB4YDAD27NnGqI2CkLYxaXt7aVA/MiUcDfzu6Or2BhQYFAj36N3SxLadiIORuDVtfHxyZGFcSzonFgwKBgL++/f17t7KuaifnpKGg46yNW17fnpvXDcP9ODU0NLe8wgeLDAtJBL41KyViIKDjrJHfHl+eFo2GQr/7/H4+vn+AQYHBw0SBvfs0rCNgoaGmg==","GEdcZWptc35uRiIQCg0XD/fp8Pfy5cSag4qSlJqistkpWVJLSkJCdmYg6+vs9SYd7tQAFxIa8KqGssO1trCnwjtNLicsJAdtXA7c+vXmPCPtugga+Cr+uojh783a1b2tUSQTHhY45mpOEvAnEeZLCgaoDg+8IeHKkvf00OTs6J49AhEhBkACRDkYDC4VBjLwFsT/ArsHzdTC6Oji3O37wyMIFioQOy42OyUbLhshJfUN2un1x+TIwtDY2ubS4fHfEBASLiAuQTA2NCEsJCAe/wTr3u3PzdS+zNjP3tjd7u0MEBY4LDNQOT1KMTMwIRgFAuvY5Ma90LS6zr/M2Nvq8g==","Ps1Uoj7NVKI+zVSiPs1Uoj7NVKI+zVSiPs1Uoj7NVKIs50ysOc1Ooi3mTKs40E6gLOhLrjrKTaMu402oNNdPoUegFwUv5kanIvBBtjTKRKYi8UG4NsVBrSrgR6Ib/TfSO8A2vjTCOLgu0kKgCBkMIvs4yD2sHvQ9uC3TQ58GHQYTHAcp6UCi8zTJNL4o3UCg7Dq5H/A+rAccBSziQZ/qOuRZqOtcottYqvFbp+hcotpXrPdZr/5WvBw0GEjoWKz3+jy/ERsXHhEp9kKn0T2x8EGs4kSetBUUJAI6xBsINNm05V2tyjwLYae0DVjHGkzyXq3JPAxhqbobSvhhoqLaUw==","UltOQDIkFgn67d/RxLaol1JbTkAyJBYJ+u3f0cS2qJdSW05AMiQWD2pcTkAyJBYI++3f0cS2qJrW7t/Rw7aol0lRRTktUnZqXlJFOSwgFAj87+LWyr6ypZmNmNfKvrGjPEM5LnBsYlhNQzkvJBoQBvzy6N7UysC1q6GWjMjJv7M6QDdfcWddVEpANi0jGhAG/PLp39bMwriupZySjszCtjk/RnpwZlxSSkA2LCMZEAb88+ng1szDubCmnJOJqMO3Nj1cdGphWE9GPDQqIRgPBvz06uHYz8a8tKqhmI+SxrszOG5tZFxTSkI6MCgfFw4G/fTs49rSycC4r6aelYzCvg==","goaPnK3C2PAJIjlOYG54fn56cWRTPigQ997HsqCSiIKCh5SmvNbyDyxFXG15fn56cmZYRzQgCvTfyrinmY6GgoKKmrLQ8BM0UGh3fn56dGpeUEAvHAj24tC+rqCUi4WCgo+oyvQeRGR4f356dGxhVUc4KBcF9OLSwrOmmpGKhIKEmL7xJ1Z0f356dm5mW09CMyQUBPTk1ca4rKCWjoiEgoav9kJ0f316dW9nXlNIOi0fEALz5NbJvLClm5OMh4OCkPRkf316dnBqYlhOQjYqHA8B9ObZzMC0qqCYkIuGg4IOfXx4dHBpYlpQRjwwJBgMAPLm2s7DuK6mnZaQioeEgw==","fG5bRjAZB/np1MS9u7vCysvEvLu8wtDj9gMUKkJWanp6aVM+KRAC+OvUxMDBws3Z3NDFwMHC0OX2/gwiOk1kd3hiSjYiCf347tTFw8fI1ubq2cvGxcLQ5/j7BhozRF10dVpBLhwB+frz1sfHzc3e8/ni0cvKxNLr/Pj/FCw6VG9yUjgnGPv2/PjYyMrT0eT8BOjW0NDF1O4A9foOJzBMam1ILyAU9fT+/tnKztrU6gYP7trV1sbW8gTy9QgiJkRjaEAnGhHw8gAC283S4NfuDBfx3trcyNn2CPHyBB4ePF1jNh8UDuzxAgjd0Nfm2vIQHvTi3uLK3PoN8O8BGhYzVQ==","Iml9Z0UsIBoYFRMQDAoGAv77+PTx7uvp5uLYw6KGjclKML4OGP4GCAcHBwYFBAIBAP78/Pr6+fn4+AHx5Dj8mUrANOYVAAkGCAcGBgUEAgEA/v38+vr5+fn4/PQL3DK7JQvt/g0JBgcIBwcGBQQCAQD+/Pv6+fn4+fj2+wj93/kCBQcICAcIBwcHBgYFBAIBAP79/Pr6+fn5+Pj4+Pj6/vwaBPoGCgcHCAcHBgUEAgEA/vz7+vn5+Pj5+vX3CwTkDP4CCAMIBggHBwcGBQQCAQD+/fz6+vn5+fj89AXtEO4V7/4PBQQICAgHBwYFBAIBAP78+/r5+fj4+fj3BP7oCg==","Rhj0+fr6+vr6+vr6+vr6+vr6+vr6+vr6+vr6+vr481E9Tev09vf4+Pj4+Pj4+Pj4+Pj4+Pj4+Pj4+Pf29ORGPT1ANOfx8/T09PT09fX19fX19fX19fX09PT08/LtGEI+QkRJF+bs7e7u7+/v7+/v8PDv7+/v7+/v7u7s6fZPREI1NjhK4Ort7u7u7+/v7+/v7+/v7+/v7u7u7erYQjg2NTExMjQ52Ojq6+zs7Ozs7Ozs7Ozs7Ozs6+vp5RI4MjExOjs8PkQO2d/h4uLi4+Pj4+Pj4+Pi4uLh4NzqSz48PDo0NDU2OUfg2t7f4ODg4ODg4ODg4ODg397av1I5NjU1NA==","E/nyCw/aCh74BfzbNOz+DgfbEQX57g4Q9PMMAfcV+u4T+vQKD9kKH/sE+Nw07P4NB9oQB/jtDhH08g0C9xX57hP69AoO2Akg/gP23jTsAAwG2hAH+OwOEvTyDgP3E/jvFPr1Cg7WCSIAAvXeM+wDCwXbEQb47A4S9fENBPgS9/AU+vYKDtYJIgAD9N0z7AQLBNwQBfjtDRL28Q4E9xH28RT69ggO1goi/wT13DTrBAwG3BAE+O0NEvbyDwT2EvbxFPn2CBDWCiH+BPbcNeoEDAbbEAP47Q0T9/IPBPYS9fES+PcGEtcKIP0E99w26QQMB9sQA/jtDRP48g8D9RP18g==","XGxtbGxtbW1tbW1sbG1tb6SUk5SUk5OTk5OTlJSTk5FqampqamppWY6RkZGRkZHPampqampqagOSkZGRkZKSHVpqampp+ZSUlZWybGpqamvClZSUlO5pampqZJSUlJSSa2lpa6SVlJRiaGhompSUmmhoaGKUlJWka2loWJKUlbJaaWjilpbvaGk9lZaWZGprw5aXBmpqH5iXp2xqbKaWlGRqPpaXBmttp5fDa2nvlpRaai6XmBJrapyW02pp75aWWWjuldJpaZyYHmoel5xpasKW+mhMlJRMaPqWwmppnJRcbqSSXG6kklxupJJcbqSSXG6kklxupJJcbqSSXG6kkg==","MFNSLEkOyIrE0en/Z2xF/AXNoYvsEiwucU8LuM61r7wyTTcz9aSv7Q46aSXM1rG7Mk44NPWkr+0NOWgky9WwujhWRUbRsLO2NlJGStOusLY4UkRL1q6ttDpWREfUsLC0MkM+96jP5lg4IMes7BRlF/mpzBI4VOrXpf40SCzAx7w6PzKuxfNiJvGV+Stf6sK0Oj8yrsXzYibxlfkrX+rCtDo8B6XvSyjYpitCE6/ZSCzooRxJHLnCQTT6ogZKIMizNkT6uNhVNMLGDFQSoeQ/NuikCl0Jw8oqWdyvAkAzvrY6QsbKMDLexRxJ3q4vUMe7OjvOyCo72sEkRNy2KU7OtA==","U2NdVk9IQjs0LSYgGRILBP728Oni29TOx8C5squlnpQYRlRsRFRSTkwqJQz1CwgEDAXs0tvQwtzlycqt2LCSods2TFpUVGRqYkImAt789QQWEN7Y3LS34+vMwr7gxJq81hgmN1Q9YnBhXyII3uPg/BYC4uressPo7Ni519bj1sjz/gspQThVbWpmLBntz9jwBu7o8dzGw+/w2MHM0fT70wry/hwwNkZycmBIMv7M3uTi4Nnn3tfI6v7P1KfR+Ab0DPYCFCguQHVgUGU+C+bm38jUv87szN3nCNzTpMrpAx4NCAUYIjVTdUpWa1AjEergwqqYrOa+4uwG9MfGp8oOLg==","n5+fn5+fn5/IyMjIyMjIyBkZGRkZGRkZf39/f39/f3+MjJqnpxMTPGRkwsK0p6fd3VZ/UMLCUH94ZGTqwt0uLrK4zPISTOzMzN//TOzsTDgyzPIZGQz/fxiyshh//+bMnZ3VIfywsA406FAYww4O6H/WnUY01tboDlDD3zQOf1mTouzsk78Yv0Ts7AkmCZNECc7OJvrOCSZ/Js5/ROxiU6HqF83NCCYI+Qhhvgj5zSYm3AhSCM1izURE60TrCKHNgfv7gfs4vvsa+/v73DiB3Dg43HX7Vtx1vqDc+xp1dfuTCZMJzs4JRJNEzkSTCX/Of85ECc7OzglEf3/OCc4JCQ==","Ri0F9vHx/Pzz/BItPE1VNCYg8sDI28GOh5225BY5QD7aAD1ra1QrME5mZEUO2NoaPjXlj4yk0ATi2b2Uo+ntvvjc+CM+cXJGJf7Szt7h4troGz8tJvrm+fTq4d7K3NnkTGhP/radt+IMKkhLKB0oRD0rE+CkhZGWuPIR/vL+GC4a8gAGIlhLS1AO3/4P+PoxKffY5+bXEBTiwYWXmdI2TwDo9y4bTHQuGvvQ3/jc6eblBisrLAjU/ggF5tvF5vLSDxP15tPiAFlaA+YVQnhA9Len2Bjn2rzD7gguDBQl5tEwSjr9Ah3hqM73BgL1BhkiVHVIC8eTnLW95RgY9e0MHg==","Iy82PEJGSktMTE1OTUk+LBT32b2mlImCgYaVq8bi/BRCJwLXsqClv+MONFVuenVeNgTVrpKEgpCs0wAoRlZaUxY8SkAxKjJHZHt5WSkB7vMCCwTpwp6LkKa8xsO7vM3yKP75+9GsoKDBAixAXmBdRi4D3L6or73F4Nra8jx4bk9GBvL40qyopazxHi5aZ2BOQxzrwp6grsjR2u3sH2Z7ZRz9y6OurNb+9wsuOFdeTC8N1KqouM/k9v3tCvsZa3I3EdnBxeT47O7KxA9EZHpqHM+ejcECGCYT7LS58Eo8Xlk2xrekr/To6jItGBAgBhIWA/70+P/y58a91+gKaT1CZg==","AixSbHp6dnJwbGVdVlRIKQHWsJOChIuQlJicoqentNniBSM5OTAXBPPw+g0iNkRDQgTPnYabvfsfOjQU88zCxvzv5NrW0OIPMEtoem1SLAjhwq+lp7LA1OoAFCAgJiAL+/z7//39/wMMBAsRGiEmGBLyktMb9tQEEvn1DQr6AQjMET8wEBgzJADn0c3uFyskIx76wrDE9hwiITdIKNOOjh0D6dLS8AUcM2BiMgvg1Or6DQPgzsriBxQSAOji8ggc6CEEMyQIPvcO8tbl7DQVIOTN/uD5E+sQFi5APs2W2bkB///8/QD+AgIHEBccIh4cE7zh8dD6AegCAvUGBv4HBA==","AhIjNkxfbnl+fXRmVD8oDvTdxrGekIeEh5GgssXY5/RYd35wVjYbCggUKDpHTEg8KAzs0byupJqPhoKEkrHlI1R4fGxQMRYE/ggeNT9APDIjDPHWxLy3sKSZkpGYrNQU1fYUMElXYnF4e3tsWT4a+NSskoWKpMbl+frq076wsL3FxMzvMmt+dV5CJAr16OXq7vDw7uvl3tfX6gMNBPDczcbGzOcycn5wWj4iCfXo5Ozx8PDv7Obf2NXoCBAF8NzOwsXJ0h9xfnJbQCMI8uHQ2ens8vv/+/Dj2OMLGA/63sjH4wxdHAwhCNT5XhVAW0cq1sToxrPX3NYA7KnvJFIPwg==","ECQ3R1ZhanBzcWxiU0IuFv7kyrOfkIaBgomUo7bL4vlUV0g4JjgfDCAQ+ALt3vD6K2E3DgjfvszatJyGmL/1MPv+R09KZDgTD/j66Ov0Bef0D+7vJRYbP+O+4qum6rHfJALq/RT/LBrg6s255REMWHY1Lw2ipsC/9g79Cu0lDhcA2u5fViQ9HAwMCQP+9vDx8fHuHgoVJO223NrU+Bzls/wNCv/v7PkWHx4Uyc3C5jI9VxAXzL0LuRMi1CUK8RT9Au0e4PQwwjIzshrLoyoYS2Qm876uy+oSJBkM/gD+9xgBBgL+/P7/AAAOAv7+yPz+9V0hERu4zt7wEBMXC/z+/Q==","CSI5TmBueH5+enFkUz4oEPfex7KgkoiCgoaPnK3C2PAcRmJwdHBpYVxbXmBiXlA2D96yloeCgoWIio2RmKjC6hxWcH52cHNuaWJeUjMbBfgEAOrVtqOgmZOOj46EjKLOG1l5fGlLKw7y4NLGubXB4RA3SUo+MSQT+t6/oIiEms4oCPsHFA/87uvm1sneGl59ZS363cq4r7ze+vzu7gsxPndUJgT48erd0r2qruQWUm5kRCAF/fft17udjJfXE1d8NHY6Lj0YCQ75ABYKFyLWviZC8N336/UK+PPyzMnUmqIBTCohsfa8EOsm6tfhKewn2xpQVLwL9gixD+Kkx2ASKw==","6vQCESU8VGl5fnhmSikI6tC+tbK2vMTK0NTW19ja3uL+ChAiMDhOXGZ3fn5xYEDw0bihnpyho6u2uMLP0d7r7r3yPnF8eGJLUnNxJeoKTm1mGZ+CiYSEkYyErOwK+tG19RAoNjk0MDI2OTUoGAb26uHa19fb4+8CHDQnuIScwNyuDUZIMRoUHzhLOvKbj+g/Pwzh1vAoSPGM8jipvz78jQ9pdHY9D1C0nMWWlIoM9ux2YWRIblC6BsqElZbfmf1coFtr1jJoYShWM2ppzjB85JM7GIqcDJu6nZ/w0YXLWtKu+u79/CYj8/gUGjwJ6g4AnwAK9gT89AzyGPYw6wwMAg==","EC5HTlRlbXJ0dHNtXUYuFPrgyKiYjIeCg4yRnqy82fMrLzY8P0JHUFZeZWx0NwT77+PTxbWsq6ahoaGhoaHoJhtjaHR0eHh4+iM1OkNVZW5rmpiWlpucnJ2goqWoqq607e7u7+70eXZwWULs7Ozs7Ozu7O7s7uzu7O7s7+3v7e3+/wABAgMDAgMqdF42IBEIAt2Yrsne9vr6+vv6+vv6+er0/gkQKDgnHB4eIyYVCAUC/ruizvQLDwbp7vj07+nmBw4UHCtBYDoKDxANDA4YLFoUt8/k6+24i6C82vIABAYAAAAAAgICAgICAgICAgIAAKA/HAAA/v7+/v7+/v7+/g==","CCI6UWNxen5+enNoVkIqEPXbw6yckIiDhIiQnKu+1O4LKkZkeH10bGJXSz8yJBcJ+uzf0sS4rKGWjYaFmLLP7DV1Mv4yaj4CKmZIFjJiSikGqJHg9KqX4tqirtvRsrvcz9DQXGttbW1tbWxscOzQzMzNzc7Ozs3Nzc3Ozs7Oz88penp6el5JSUhJQxf55LbAKEgsFufPtre3t7OGh4eIsCZCQkdtbGxsbGxra2tqam2rlZWVlpaWlpaWl5amwsLCAAAAAAAAAAAAAAA2cQrh5ert8PP29/n6/Pz9/v7//wD8/Pz8/Pz8DzYqKBrl9fX29/j4+fr6+vv7+/v7/Pz8/A==","0dzzDitKZHZ+emtUNxj63si5s7W9y9rm7vDt5NvSzMvn+x1AXHB5fH5+dmBAHxESBunLsp6PhYWSprTCy9bc39zj8QkoSmh8fnBOKgnl0sjK0d7w+/337uLZ09PV1tfZ2u0PO2p+a1ZWZl5HPTQZ9NjNzsrCurWztLbAy9XY1dLh3NHdDkhqe3lWLgv02cS8yOICGx8O9ODZ3urw8+7n4tTc4egYQXB6aDoVBfzguJ+cvvUoSkcwC+7m7vLo2s/MFCotMkBRZnJdUlhZU1A+A+T/2rOhlY6YkIOdvs7a5PHG06vOY14QHsfSqs5hYQ0gx9OrzGJfDiDG1KzMZVwPHw==","DiQ2SFdmdHx/fnZoVj8lDPXcxrOgkoiEg4aPn7LF2fMLHjRGU11ocnh8em9cRi4U+t3BqZiNhoKBhpGjuM/n/BEeKzhEUFpkampmW0s4Iw776djGs6CPhIKJma/H3vMCBhwwQlNgbnh+fnhqUzcW+OHQxr20qp6UkJKapbLC1+0WGCUwOUlZZHJ+emVIMBv649jPxrqxppiQlpqiudLxDeng3uX5GDpUaHZ+dVo0DerRwrarqKy2yd3y/gIA//rzByM8T1hebHl+dVs0COHMzuH0/Pz05tXNw6+WiIuewOgeJzlAQUhUZHJ3cWVSLwXq7O7aycu8o5OIgoiSocb3Fg==","yPwmQk1IMg3froyU5lB8aDgE2r6zuM7zIVJ0bBqwhJiww9vp7gktMjVgTl0t4MqelqKzy+UbQF52Zlwa69K6ogIeMjgCzuH7/gQXHvDX8gkIJSFBJcmNt/MIKVAn1sDf9+fVwKuWDnNYPicTAfTq5OLi5uvy+gMLEhgcHRsXDwXc5PHAzegEIT5YcUT/yNTc3dnOv9DgJE5qSSsR++rg2wQCAgICAQEBAQAAAAAAAAAAAAAAAAAAAAAAAADp1yQJ+vLs6Ojr8vwJGCg5SRr8tcbW5PH8BQ4UGBsbGRTOCwIBAQEBAQEBATQUAf////////////7H8gA2EgLA9gABAQ==","CiI5TmBueH5+enFkUj4oEPbex7KgkoiCgoaPnK7C2PCe5DFXenx8fHx8fHxwRBm7jabEsNL0vISEkt7zzcPFpRQ2Snh7e3p6enp5XEkeGAHm5ubHtqGGhoaGhoaHo7joNjY2NjY2NjY1NTU1NTU0397e3t7e3t7e3tqHiIir4DZQbGxsbGxra2trampqamprvJSTk5SUlJSUlJWVlZaWlBwoKCgoKCgoKDRiKCcnJyjk2NjY2L2s2NjZ2dnZ2dnYLsHCwsLD/Tg4ODg3Nzc3NiizwsLCwsLCwsMVODg4NzcODg4ODg4ODg4ODg4ODg4ODg4O6Obm2MDGEgrm5ukCDg==","DTFQaXl/fHJjUkExIhYMBP317ODTxLKhkoeChpKoxunsAhsZ/NKytuYycndC7KGDou5Cd3I24JmHtPs1SDYR8qm05svYCzl1Itk2Gpim2vocMm5Hv9YUwKHiDUIrEFozn+Rr9s4+aO3BLB7XGmzUsDAPxA0o2uAQALO/SBjGEiRYVEs9LiDo7Pb4+Pj5/gwcLTxJVF6zlpOKhYqexvoqTKiuw+oVN1BhbHFySZCVm6W0yucFGyozODo6OSz7urGqWpuIwDhzdr6FsCRua/Ow0AIUCP7+/v7+/v7+8+XwJEoJCv///wAAAAD/AP7sAgcGDQ/m8isM9/32wgoKBAgO8g==","Dy5JXmx2e319enVsX0wyFfXWuqWXjoiEgoGFjZyzzu4DFCc6TWBwe357cGBNNx4E7dbDs6ignJqamp6ot8jd8vwKKElTY3Z+d25rXj8qGwLr2sW8vLOglJqcnqi7zNnp4QMnTG59dFpFPDg2NSgaA+3axry2vs7c39rJwLSwtsjhDDdieH1sWVJHLgLh4fQA/ebi5vAA+/HjyrGkmKW1xu8MNlBse3x2V0UzHA0EAfvs4uLi2Nbf1ti9qKeYrbzTHujD2AUuNAjNoZrZOXN3WTkc+9GihZPPAyIoHBMaKCsz6NLwDy9XUiwBu4yY0BlaPO/S6gwrUUQm8rGIl9ghWg==","Bh00SFtpdXx/fHRmVD4lC/LaxLChlY6Kio6VobDD2fATJjVARkhLTlVcXlpPQTAbAujTw7KfjYODjaC3zuDvAf0iWHxtUEMm67i1zdLJ1/wYK0RQRTAY8cCqs7y2u9Hm6vr3+v321QZGdG5cM/7s/dquoKDYEyg+K+e+0ewXCvbNDTlPbloL6Onw8Nvk9AcPIjsI9BEE6Obq7dLC8AbryEBYTzkK7KqajazeL2pyaE4yDObGuLXJ0uYV7Obh+hQgeTr+AR0dIPUB0ur2zM8YKRo8DQ0EKRoRvaC0zsXU6UoX/CPg/OctLufS4RgwJufu80/4zaciDyXfFAj4zvwKAg==","DzRVbXx+d2dSOyQSBP37/gIEBP7y4Mu0noyDg46kw+c6eFlhZV5hWVJEOCMK/cO8LksM+eXLwLGpoKGem6mOqE5YW1VYWVVQST8wIgzy3qhDMBb35NTEubKsp6mopq6WUVBOT1BQTkpDOiweC/XarkYsEPrm18rAuLOxsLCxr51SU1JSUlJQS0Q6Lh4M9NirSC0S+ubWyL62sa6urq6smklOR0lISUZDPDQpGgr24LBALA776dvOxr66uLe4uLihRkVDRENEQj44MCYYCfjgtj0mD/vq3tPKw7+9vLy+vKhGQ0BBQkJAPDcvJBgJ9+G5PSQO++ve1MvFwb6+vr++qw==","CSI5TmBueH5+enFkUz4oEPfex7KgkoiCgoaPnK3C2PAoZULy2hhpdjwECTZKKfvyCQzkusDtAtaUjNEdHNKbwTYzzjBl9yB1Gg1jJvk/GN4aALz5853b/JXAFLKvLe6yPeI0Gh9LDWQKXRM+HRga/ATw3vK68qnotdHatwqrL7o43j0WIVAOYB1DNx43DhgJ9vTrzuu32sa17KH+vesA0SMO+ipCHCBLPhswPxkLIA3p9frTyubUs87nxL/z+NTwEx0bFxspOkNANCgkJCIYBvbs6ubdzsLAydbc2tTV5P0EDRUdJCotLzAuKiYfFw8G/PTr49zX09HQ0tba4enx+g==","CSI5TmBueH5+enFkUz4oEPfex7KgkoiCgoaPnK3C2PAMLUpgcXt/fnhvY1REMiAM+OXSwLCglIqEgoSMm7DL6hI+X3J8f3x3bmRXSTorGgr66dnKuq2glYyFgoSMnLjgHWB2fn57dGxiV0w+MiQWCPrt39LEuKyhlo6IhISKm8Ylen99eXJqYlhNQjYrIBQI/PDk2MzAtqyimZGLiIeOphp4dG9oYVlQSD82LCIYEAb88ujf1szEu7OrpJ6al5iiFHRuaGBYUUlAODAnHxYNBfzz6+La0srCu7Stp6KfnqQScmxlXVZORj42LiYdFQwE/PTs5NzUzMW+t7CrpqKgpA==","lZyqvdXvCiY/VWd0fH98c2ZWQiwW/+rWxLWpoJqXlZTQ8Shde3ZSHezQ0OoPLz01GvjbzdDe8Pz99ObYz8zMzNoea3U06NYIR1Qk5tP1JTIQ49LmBQ/63tHa6Ovh1dDQ5U5yEtkjYSLZAEUq4OclJunZBhfv1OwB7NTb6uLU0tTwajzdNlbqAlAI4DIi2gko5uga9tgA/dfm9tzX5NvS1P1w+CBT4jso5UT++DbkCxnbFPrgDuPp/Nfr6NXk2dTWCWDpXfcyIP8+5DzsGwn0Ht8a4wLz5/7a+Nro39re1NYVPhE3DDAIKQQiABz8FfgO9AfwAOz55/Lj69/k297X1g==","m52qt8TS3+z5BhQhLjtIKLa8ydfk8f4MGCYzQE5baEicnqy6yNXj8f4MGig2RCACuL/N2+j2BBIgLjtJV2RBJJ6grrzL2ej2BBIgLz0j+Qi7wtDf7fwKGCY0Q1FgRRsqoKKxwM7e7fwLGig4HPD+D77G1ePyARAfLj5MXEAUIzOho7LC0uLyAhIiMRrm9QUWwcjY6PgIGCg3R1dACxsqPKKltcbW6PgJGioT2ur7DB7EzN3u/w8gMUJSOgITJDRHpKa4ydvt/hAiGsze8AIUJsfQ4vQFFig6TET2CBosPlKmqbvO4fMGGRG+0uT3Ch0wzNXo+g4gM0Y96v4RJDZKXw==","U2NdVk9IQjs0LSYgGRILBP728Oni29TOx8C5squlnpRTYVhORjwzKiAYDgX88unfGhkQBv706+LYz8a9tKqhllJeUkY7LyQYIRgMAPXp3dAmJRoOAvbr3+jg1Mi8sKSWUltNPjAiFAUlHA4A8uTVxi4uIBIE9ufY+PDi08W3qJhRWUk5KhoK+SQaCvvq28u5ODkpGQn56dkD+urayrqqmFBSOyQmEvvkKyAJ8vTgybE/PCYPEPzmzhYK9N3eyrSaT0ouEiMM8NIyJAjr/OXIqkU+IgUW/+LFJRf73u/YvJ1OQyD8IAXivTcmBOAD6MWgTkMg/CAF4r03JgTgA+jFoA==","iJi4qOj42MhIWHhoKDgYCAgYOChoeFhIyNj46Ki4mIiQstP0MBxqQsvwpb1rSigGBihJarum9MxBZhsz9dSykZTE/BxiCK/aT0Ig36gESRkRQDqg5ggsV9LF4VwkBMycnOQeYp7mIFvYsFgf3q5WHRRcpuoXX6jjUSngp1cm3qSg8EDW3i4G0FQWxiof2AAoGCzIE1a2Bknc2j7uplAAsKgIJ8k59vk3yAoGzFb32zUkCelGvPY3u0UKyEja9xm4rBwFAj7ZMstB5v4J4BbAOSHiBQIEE71AzCD+CRrcNsS0PMRMtDzETLQ8xEy0PMRMNLxEzDS8RMw0vETMNLxEzA==","OGBtdXp8fn5+fHp2cGleSMynmpGLh4SCgoKDhoqQnLJGd314dHV2dXNwamViYVtFzqignpyXko6LiouMioSFnk18cmJhZmZjX1tWTkhISjvWuLe5tKymop6amp6fkoSWUnhbS1ZbVE5KR0Q9My81LeDL0M/Fvrq3s62mqLOsjJBWcUVCVE5EQD04NDEoICQi6Nvg29DMycTAvbWruMGZjFdiMENNOjY1MCsmJB4VFhXw6uzk3dvW0szKyLi20K6MWVMmSD4tMCwmIh0aFg8MDPj08uvn5N/b1tDTybTUwIxbQSVIKSkqIR4aFhIOCgYC/vr28+/r5+Pg2dTcvM7TjA==","BBAcKTZFVWtyWkk6LCAUCPzw5NfKu6uVjqa3xtTg7PgGFCIyQ1ZvcltLPjImGxEG/PLn3dLGuKmWiqW5ytro9wYYKTxRbHJcTUA1KiEYDgb99Ovi2M7DtqiWjKnA0uT2CB40TW5uWkxANi0kHBQMBf327ube1czCt6qYjKzG3fMKJkVrb1pMQjgvJyAYEgsE/vfw6eLb08rBtqqYjLPS7g43aGhUSD41LicgGhQOCQP++PPt6OLb1M3Eu6+ekL7oGF9mUEQ6MiwmIBoWEAwIA/769fDs5+Lc1tDIv7OildhFWEI3LygjHhoWEg8MCAUC//z49fLu6ufj3tnTy8Gvog==","CiQ8UGNwen5+eXBiUT0mD/ffybSilImCgYWNmaq/1vAQOFlwfX52aFRALBsOBgIAAP/79OnZxrGdjYOCjKC/5hlUdn5vVDgkGhkeJCckGgv66t7Z2uDm6ODOs5eEhaHWKnV0UTtATEg3JiAgHRQKA/747uXg4dzOu7S8xreUhbxAdk9XWkFAQDIsKCAYEgsE/vfw6ePa1dDCvsKspLSUoFReZVVRSkI9NC4nIBkSCwT+9vDo4trUzcXAtrOooqGSV2tkXFVORj84MCkiGhMMBP327+fg2dLKw7y0raWelo5TYltVTkhBOjMtJh8YEgsE/vfw6uLc1c7Iwbq0raaelw==","9+b7ChzWhaTQ4vbKzNoDYkg5XWZS+bLK8iBICvr+/SUK/eoI/baQ5OrX7uDu+P5EKAobV2URygYEETEm/uzIIgQE0vj9uZr11Lzr2gP9Ai08IBk+XA/kOAIEDxz7D84i9gvO6fXZlfLWwczuCgLkSy8mHEI2F/dG/gMEDPsi1STuEc3s4uKa29XNt/v6EN5VJywlSScr+z3+EQAHAR3hHuwRzvjP2sDHzNq/+OAi/C8sNCo1KDr8LQAh9AQJDvsO7g7Q99Dcx83O2sL33yAAMCkwJzEkN/8tAB70AgYN/hDyD9b41N7N1NbhyvfhGv8rJiwjKx4u/igCHPYBBAn+Dw==","1+L4FjdWbnx+c1w/Hv/n2NbW1tbW1tbW1tbW1tbW1tbK4xBCa35zTx7tzsrcAClKWVE1DebNx8fHx8fHx8fHx8/7QHR4SgbT0PYsVFMs9dDQ8Bw5NhTozcnJycnJycnJ4Sx0ZRDa+kBYJeTgEj0t9tjxHSgE3NXV1dXV1dXV1dXwWWf98UZG8PI1K+jxJhfj8BkH4O8O+97b29vb29vb2wtxBSRH8DEa9Cz6ABrsCATqCfLwAenl5eXl5eXl5eXkJkIiKR4YGQoUAQ/6CvYG8+7u7u7u7u7u7u7u7u7u7u5AICowGwoPEgj/AfPz8/Pz8/Pz8/Pz8/Pz8/Pz8/T09A==","AQEBAQEDGmBwKQUBAQEBAPrt1Ly4zej4/wABAQEBAQEeWFLjqKSttq6Yi4OmA0tBRFZgXVpXUkUe5srQ6Pf9A5+z1O7w8u3k7Aw2QzYb9dSvqO8xKA4IDxonNlZ7QsSdHjlPX15MKA4GAvwEB/71+gQHBgLs3Mibh7TS4PP8AAb50LSejJPC+An99u7o8gIMJCz82vMtY3x4WjkQ2eAdI1Mm3Nw4VjseBuPHtpSuGGN8XRzy3+Di4evnvKPF9ShLEBgpSm18TuraN3pwRBrqxqmivuHqzKylssbY7gEEAgbXurrb5s6lhoy99hEH7ODvCSpLX2pdPSMqRUo1FP/17w==","FEdsfXpnTDEdFBQaICAZC/rq4eDk6u3m1bufioKOrt4veXhsXl9iOB8pFP0IIUMy37nX8gP02N/TpZ6kl4uDtkVwd3ZZYGc0JCQd8w4nMUzKw9jqCfTU5M6qlK6QhZScS2BvbVJaWDchGiHyECAuTcLO2usI89/f0reWtpaSnJ1NY3NwVFxYOCIcIvIQITBOwMzX6gj0397QtZO0lJCZm0tkbmxUWFU3IRwg8RIfLFHCytrrBvXh39K1l7iVk56aSmBrak9XUjYgHRz0EB4rTsLO2+sI9OLg1Laet5qXoZ1JXWhnTFVQNB8cHPQQHipMw87c7Aj04+DUuKC5nJikoA==","CSI5TmBueH5+enFkUz4oEPfex7KgkoiCgoaPnK3C2PATOlxyeXFcPhv6387K0uX9Fyw5Oi4W9tKwlISDka7UABhUeHpdLvza1u4cTnJ7Yi7ssIqEn84AIysW6beQhZvNHVZjQgjd3QpKd3ZF/8rC5h1ANwK7ioq39yIh9byaqOMeWk4P2uIla3hB9dT3O1066Kms6CIi45qGtwQsEM2kwCZbLuDbLHZgCdwQYGMPw9QiQgKmmeIiBKyGxBsm3qXMKFgNzQptYP7mPngz1epFSeGl5zABmpf3Hs6IwSYgxLEtS+rdTGUA7lZq/uRHVeTHJjPCpggYrJX9FK6eDCnIvA==","ETJCT1BKVGdxfHpgPycOAAD338ipioOMlqe2sq+6yeUaPDpIPRkpTFNpek0gFPfrDhHx5MKMjquwzOrNtsTE1xpDSE47GCNFVm97Th0H7eoOGP/qwYyKprXU6s+zt7rWJU5NRC5OZHVoVnlqUyLn8wcb8bSdhKKiiJmpzsSys8coVEs9NmFra0gfT3Z7RgsK+PjOi4ai3MiYlpjCybeuwypyd21qXE5GKxc7dHJEIxD24seYhrXm3b+0qJiUjIi9I2V+dmJSQjoqISg1LBAB/AMA9dvK1d7aysCzopCCkcg+W1BMQzUKYFkqGElPPnI05Iy4vqXq2LeY4eK4t7KpqA==","5ujx+gQMFh8oMjtETVZga6qfqLG6xM3W3+jy+gQNFiAqOERQ8vT+ChUgLDdCTllm4N7p9piZpLC7xtHd6PP+Cl5ucXQOBggKDA8RFBYYGx0cHiAkvbW4ury/wcPGyMrLXG1ubkA8PDz38PDw8PDw8CQoKCr79/b4sqysrKyrrKksQkpQWF9mbiESCwT99u7n5+71/AMKEhrMvravqKGakQYeLTxKWGd2VklANi0kGhKmqrjG1eTyAeHUysG4rqWaNklJUVhgaHESEBgfJy82QNLOztbe5e32l5ScpKy0u8I8SgYMFBwkLDQ8RExVXWVv3NWSl5+nr7e/x9DY4Ojw9w==","CSI5TmBueH5+enFkUz4oEPfex7KgkoiCgoaPnK3C2PAkOkdPU1VWVlZWVVRQSj4qD/DRtqKSh4KCho6dsMroCDFHT1FQUE9OTk9QUFFQSjgY8cyxnpCGgoGFjZqsxecOQFVWUk5MSklJSkxOUFVXSCHuxKuajISBgYKKlqa84hVPYlpQS0lGRUVGSEpOWGJXKuq7ppmLgoKCgYiWorTcGmBvW0tHRUJAQEFER0lWbGgy5LCinIuChoeCiJiiqtMfbnhaREJCPjw8PUFDQ1JyeDrdpqKhjYKLjoSInaSiyiNydEw1NzgyMTEyNjg0Q2t6PNilrrOckJ6ikpavsqTEIw==","UE86LCQiJiwyODk3MCYZCvrq3dLKx8jM0tjd3dbKtpxPTkFASFJXU0c2JRgPCgYC/vv48uvezr2vqay2vsC1nE9SUmBmWkMxLTAvJxsQCAL++vPo3NLQ09HDrJydqrCdTl5uY0lKTj8yMCwgGRQMBP727uji19DPxbS0uqSQnpxQcGRZW0lKPjkxKSIaEwwF/fbu5+DY0sjFuLeqo6SMmFZualxWUUhBOjIqIhsUDAX99u7n39jQyMG6sqyimJeMWGhhWlRMRT43MCghGhMMBP327+jg2dLLxLy1rqagmZBUZV9YUUpDPDUuJyAZEgsE/vbw6OLa1M3Gv7ixqqOckg==","DCtGW2p1e35/fHduYEwyFPTVuqWWi4WCgYSJkqC0zuwTO1hpc3h7fHx8eXRsXUQe8siqloyGgoGBgoSKk6S/5iFTa3R4eXl6enl5eHVuWzDwtpaJhIKBgYGBgoSHkqvfPGx1dnd3d3d3d3d3dnZwTvCehoKBgYGBgYGBgYKElNVYc3R0dHR0dHR0dHR0dHRm9o6CgYGBgYGBgYGBgYGH0GtycnJycnJycnJycnJycnAHhYGBgYGBgYGBgYGBgYLSbm9vb29vb29vb29vb29vbxqCgoKCgoKCgoKCgoKCguBrbGxsbGxsbGxsbGxsbGxsLoKCgoKCgoKCgoKCgoKD9A==","CSE3S11sd31/e3JlVD4nDvXdxrKgkomEg4eQnq/E2vEuOT4+PDYxKyUeFxEMBwQFCA4UFg741rCQgoiewOQEHBxRcH58aksoC/r2+gQMEhYYFA8G+ejVw7SooZybobTdSFBKOykcEhAbKjc/Mx0E6+Pm7/4FB/rgv5iEhJrJ/ChISjEOBRIcJEBuekwN4+UMNEMu+LyYj46Jj6O4zu0SMg42TENTdnxgMgj09fz5+PwGAwYA+PLi3dbAwsCpkZzWyAQiR2J8XyD77+30/AIGBAP47+nq8vf9BAsOB+rGmI00MR0hJTBEOycA0sbXAS1MXFI2DN+8ppKLjqK+6AccMQ==","+nd8e3l4dnRycG5tbGpoWPmIhYaIioyOj5CSlJaYmqhbXFlZWllYWFhXV1dXV1VVW9mEiIiIiIiIioqJioybRvIme3p3dXJwbmxqX0IoFQgA/O+2i4yOkZOWmJqcpLrQa35+fXxep5Exbnt7enhxQAuRh4eIiInMDgTRmYyMjqCUnN1ddFBrcG5sa2lnZQqFiMiLioyw6A9DXUr4jo6cvIuMCWdnZsyMGmZlWI6KjOBmZmVProqLjNRcZ2ZlNKCKkpKUuTdfX15dO+7+RFsBkJCSlS5dXFqWkpLdXl1cUJGkjpCmamppHo+PlGZpaGYNxI6OkGJoaAaPjpAIamloSg==","uxRqfH9/fnp1alY/LiIO+eve0cS4rqmrtLy6sqmko6cmoISBhblUdXl2a0kTCSg+ORbEmo+KjpimyPQpVGhuZ0paY2lucnR2eHl6enZvZVDSoZWOiYaDgoGBgoaKkp7XV29vb29ubm1samhkXlIcAAD0tKSdmZaVlJKSkZGQkI5YWVhYWVlZWFhYWFhYWFhYWrCSkpKKhISEh5KSkpKQQH59bru0xGArurKyujBydWnnxM5GUefFu7q+xMzEugp6z9LVFGZwdnt9fn5+RmLbvLq5urq6vL7Cxs3W3drW1dIE2czW9hspNDtCUFpcWC7CjY+fBSXQqrMEOzgM3dT1DQ==","EiEuOkVOWF9laGhjWks3HgLmya+aioKBhpGgs8jc7wIjGQsHECI8WHF9fXZkSiwO8ti/qJqUlJaZnqi93v8GGwIlRl5wenp3cWNMNzEvDtq6utDr+vHawKWQgoKMo8HgydHxQGp+fHt+f3hmQA3m0srIxcXHyMXExMbIysrIyctAUl9ma21samtsbGtqaGgt5cWtnI+IhYSCgoOGjZiq+MzcHllocnp9f358e2ER8NrLwry6urq6u7y9v76+v8HF7DB8eW5jWVJMRkI/PDo4NjYquJSJiI2Um6KorrO6xdfuFmZsXlJJQz88PT08OTY0MS6jhJCcpq2ytrq9wMbP3Q==","BhQkMkJQX258cmFQPi4cC/ro18a0o5KEjp2su8rZ6Pa8oLzN3u8AESI0RFZneDwCyJCgrr7O3u7+Dh4sO1hIAsK6Bvru3u0uV0xCNywiFw0C9+3iv5KovtTqABYsQVT7LNmpyekOXFBGOzAmHhQLA/vz6+Td1tDKxL+6ukNBLhsI16UGOmcmDgANHhEE+AANDQH16fcFBffroKrF4P5oOBoK+ejXxrUKbmJTQjIiEgLy49PDs6SU7kc2JhUE8+L7BgwSGB4kKjA2GfPe9A4tJR8YEd71xKjS1tzi6O70+gAAFfQF3gQc+gYDC/YMBPIABQn6+Q7iEO4R7BLw/9037Q==","K0BSYGZpYEo6KxsSDxAQFBgaE/3lyrCcjYSBhJO45g9ke3pmSi4YCAMDAwMDAwQFBQUFBQUFBP3oxKSTiIiO8ggMKUROV19rdn1yaU49Ggn21sW1rpyakZGWn6m2zugACgsLHDRUaHp2YkwqJxgQCPvZyMjGxMPB07GhrLjP6QAoMUZfeHYREBAQEBAQEBAQEA8ODN7HxsTCwb+9vLy81gwWHCIoJhokLDZFUFVOV2Bgho6cpKCmr7rI1eDs9/wD/ld6eTj6/Pz+/wAAAAAAAAAAAAAAAP/9/f39/NaMibpB/f3+/wACAgICAgICAgICAgICAgIAAAAA//60iugIdw==","ABcuQ1Vkb3Z4dm9kVUMuFwDp0r2rnJGKiIqRnKu90ukALUZSXm12eHh2bmFSQi0WAOrTvq6fkoqIiIqToq660wBBXV5jcnh0cnFoWUw+KRMA7dfCtKeYj46MiI6doqO/AFNxaGd0eG9ra2FQRDklEADw28e8sJ+VlZGIjJmYj60AXHhnYWxtYVtcUkE4MB8MAPTh0Mi/rqSln5OUn5mIpABeeGJYYWBRS0xCMysmGAgA+Oja1c2+tLWvoJ+onoiiAGB4XlFYVkY+PzcoIh8TBQD77eHe2MnBwrqqqK+iiKAAYXhbS1JOPDU2Lh8bGg8DAP3x5uXh0srLxLKutaWInw==","ABcuQ1Vkb3Z4dm9kVUMuFwDp0r2rnJGKiIqRnKu90ukALUZSXm12eHh2bmFSQi0WAOrTvq6fkoqIiIqToq660wBBXV5jcnh0cnFoWUw+KRMA7dfCtKeYj46MiI6doqO/AFNxaGd0eG9ra2FQRDklEADw28e8sJ+VlZGIjJmYj60AXHhnYWxtYVtcUkE4MB8MAPTh0Mi/rqSln5OUn5mIpABeeGJYYWBRS0xCMysmGAgA+Oja1c2+tLWvoJ+onoiiAGB4XlFYVkY+PzcoIh8TBQD77eHe2MnBwrqqqK+iiKAAYXhbS1JOPDU2Lh8bGg8DAP3x5uXh0srLxLKutaWInw==","ABcuQ1Vkb3Z4dm9kVUMuFwDp0r2rnJGKiIqRnKu90ukALUZSXm12eHh2bmFSQi0WAOrTvq6fkoqIiIqToq660wBBXV5jcnh0cnFoWUw+KRMA7dfCtKeYj46MiI6doqO/AFNxaGd0eG9ra2FQRDklEADw28e8sJ+VlZGIjJmYj60AXHhnYWxtYVtcUkE4MB8MAPTh0Mi/rqSln5OUn5mIpABeeGJYYWBRS0xCMysmGAgA+Oja1c2+tLWvoJ+onoiiAGB4XlFYVkY+PzcoIh8TBQD77eHe2MnBwrqqqK+iiKAAYXhbS1JOPDU2Lh8bGg8DAP3x5uXh0srLxLKutaWInw==","ABcuQ1Vkb3Z4dm9kVUMuFwDp0r2rnJGKiIqRnKu90ukALUZSXm12eHh2bmFSQi0WAOrTvq6fkoqIiIqToq660wBBXV5jcnh0cnFoWUw+KRMA7dfCtKeYj46MiI6doqO/AFNxaGd0eG9ra2FQRDklEADw28e8sJ+VlZGIjJmYj60AXHhnYWxtYVtcUkE4MB8MAPTh0Mi/rqSln5OUn5mIpABeeGJYYWBRS0xCMysmGAgA+Oja1c2+tLWvoJ+onoiiAGB4XlFYVkY+PzcoIh8TBQD77eHe2MnBwrqqqK+iiKAAYXhbS1JOPDU2Lh8bGg8DAP3x5uXh0srLxLKutaWInw==","ABcuQ1Vkb3Z4dm9kVUMuFwDp0r2rnJGKiIqRnKu90ukALUZSXm12eHh2bmFSQi0WAOrTvq6fkoqIiIqToq660wBBXV5jcnh0cnFoWUw+KRMA7dfCtKeYj46MiI6doqO/AFNxaGd0eG9ra2FQRDklEADw28e8sJ+VlZGIjJmYj60AXHhnYWxtYVtcUkE4MB8MAPTh0Mi/rqSln5OUn5mIpABeeGJYYWBRS0xCMysmGAgA+Oja1c2+tLWvoJ+onoiiAGB4XlFYVkY+PzcoIh8TBQD77eHe2MnBwrqqqK+iiKAAYXhbS1JOPDU2Lh8bGg8DAP3x5uXh0srLxLKutaWInw==","ABcuQ1Vkb3Z4dm9kVUMuFwDp0r2rnJGKiIqRnKu90ukALUZSXm12eHh2bmFSQi0WAOrTvq6fkoqIiIqToq660wBBXV5jcnh0cnFoWUw+KRMA7dfCtKeYj46MiI6doqO/AFNxaGd0eG9ra2FQRDklEADw28e8sJ+VlZGIjJmYj60AXHhnYWxtYVtcUkE4MB8MAPTh0Mi/rqSln5OUn5mIpABeeGJYYWBRS0xCMysmGAgA+Oja1c2+tLWvoJ+onoiiAGB4XlFYVkY+PzcoIh8TBQD77eHe2MnBwrqqqK+iiKAAYXhbS1JOPDU2Lh8bGg8DAP3x5uXh0srLxLKutaWInw==","ABcuQ1Vkb3Z4dm9kVUMuFwDp0r2rnJGKiIqRnKu90ukALUZSXm12eHh2bmFSQi0WAOrTvq6fkoqIiIqToq660wBBXV5jcnh0cnFoWUw+KRMA7dfCtKeYj46MiI6doqO/AFNxaGd0eG9ra2FQRDklEADw28e8sJ+VlZGIjJmYj60AXHhnYWxtYVtcUkE4MB8MAPTh0Mi/rqSln5OUn5mIpABeeGJYYWBRS0xCMysmGAgA+Oja1c2+tLWvoJ+onoiiAGB4XlFYVkY+PzcoIh8TBQD77eHe2MnBwrqqqK+iiKAAYXhbS1JOPDU2Lh8bGg8DAP3x5uXh0srLxLKutaWInw==","ABcuQ1Vkb3Z4dm9kVUMuFwDp0r2rnJGKiIqRnKu90ukALUZSXm12eHh2bmFSQi0WAOrTvq6fkoqIiIqToq660wBBXV5jcnh0cnFoWUw+KRMA7dfCtKeYj46MiI6doqO/AFNxaGd0eG9ra2FQRDklEADw28e8sJ+VlZGIjJmYj60AXHhnYWxtYVtcUkE4MB8MAPTh0Mi/rqSln5OUn5mIpABeeGJYYWBRS0xCMysmGAgA+Oja1c2+tLWvoJ+onoiiAGB4XlFYVkY+PzcoIh8TBQD77eHe2MnBwrqqqK+iiKAAYXhbS1JOPDU2Lh8bGg8DAP3x5uXh0srLxLKutaWInw==","ABcuQ1Vkb3Z4dm9kVUMuFwDp0r2rnJGKiIqRnKu90ukALUZSXm12eHh2bmFSQi0WAOrTvq6fkoqIiIqToq660wBBXV5jcnh0cnFoWUw+KRMA7dfCtKeYj46MiI6doqO/AFNxaGd0eG9ra2FQRDklEADw28e8sJ+VlZGIjJmYj60AXHhnYWxtYVtcUkE4MB8MAPTh0Mi/rqSln5OUn5mIpABeeGJYYWBRS0xCMysmGAgA+Oja1c2+tLWvoJ+onoiiAGB4XlFYVkY+PzcoIh8TBQD77eHe2MnBwrqqqK+iiKAAYXhbS1JOPDU2Lh8bGg8DAP3x5uXh0srLxLKutaWInw==","ABcuQ1Vkb3Z4dm9kVUMuFwDp0r2rnJGKiIqRnKu90ukALUZSXm12eHh2bmFSQi0WAOrTvq6fkoqIiIqToq660wBBXV5jcnh0cnFoWUw+KRMA7dfCtKeYj46MiI6doqO/AFNxaGd0eG9ra2FQRDklEADw28e8sJ+VlZGIjJmYj60AXHhnYWxtYVtcUkE4MB8MAPTh0Mi/rqSln5OUn5mIpABeeGJYYWBRS0xCMysmGAgA+Oja1c2+tLWvoJ+onoiiAGB4XlFYVkY+PzcoIh8TBQD77eHe2MnBwrqqqK+iiKAAYXhbS1JOPDU2Lh8bGg8DAP3x5uXh0srLxLKutaWInw==","ABcuQ1Vkb3Z4dm9kVUMuFwDp0r2rnJGKiIqRnKu90ukALUZSXm12eHh2bmFSQi0WAOrTvq6fkoqIiIqToq660wBBXV5jcnh0cnFoWUw+KRMA7dfCtKeYj46MiI6doqO/AFNxaGd0eG9ra2FQRDklEADw28e8sJ+VlZGIjJmYj60AXHhnYWxtYVtcUkE4MB8MAPTh0Mi/rqSln5OUn5mIpABeeGJYYWBRS0xCMysmGAgA+Oja1c2+tLWvoJ+onoiiAGB4XlFYVkY+PzcoIh8TBQD77eHe2MnBwrqqqK+iiKAAYXhbS1JOPDU2Lh8bGg8DAP3x5uXh0srLxLKutaWInw==","ABcuQ1Vkb3Z4dm9kVUMuFwDp0r2rnJGKiIqRnKu90ukALUZSXm12eHh2bmFSQi0WAOrTvq6fkoqIiIqToq660wBBXV5jcnh0cnFoWUw+KRMA7dfCtKeYj46MiI6doqO/AFNxaGd0eG9ra2FQRDklEADw28e8sJ+VlZGIjJmYj60AXHhnYWxtYVtcUkE4MB8MAPTh0Mi/rqSln5OUn5mIpABeeGJYYWBRS0xCMysmGAgA+Oja1c2+tLWvoJ+onoiiAGB4XlFYVkY+PzcoIh8TBQD77eHe2MnBwrqqqK+iiKAAYXhbS1JOPDU2Lh8bGg8DAP3x5uXh0srLxLKutaWInw==","ABcuQ1Vkb3Z4dm9kVUMuFwDp0r2rnJGKiIqRnKu90ukALUZSXm12eHh2bmFSQi0WAOrTvq6fkoqIiIqToq660wBBXV5jcnh0cnFoWUw+KRMA7dfCtKeYj46MiI6doqO/AFNxaGd0eG9ra2FQRDklEADw28e8sJ+VlZGIjJmYj60AXHhnYWxtYVtcUkE4MB8MAPTh0Mi/rqSln5OUn5mIpABeeGJYYWBRS0xCMysmGAgA+Oja1c2+tLWvoJ+onoiiAGB4XlFYVkY+PzcoIh8TBQD77eHe2MnBwrqqqK+iiKAAYXhbS1JOPDU2Lh8bGg8DAP3x5uXh0srLxLKutaWInw==","ABcuQ1Vkb3Z4dm9kVUMuFwDp0r2rnJGKiIqRnKu90ukALUZSXm12eHh2bmFSQi0WAOrTvq6fkoqIiIqToq660wBBXV5jcnh0cnFoWUw+KRMA7dfCtKeYj46MiI6doqO/AFNxaGd0eG9ra2FQRDklEADw28e8sJ+VlZGIjJmYj60AXHhnYWxtYVtcUkE4MB8MAPTh0Mi/rqSln5OUn5mIpABeeGJYYWBRS0xCMysmGAgA+Oja1c2+tLWvoJ+onoiiAGB4XlFYVkY+PzcoIh8TBQD77eHe2MnBwrqqqK+iiKAAYXhbS1JOPDU2Lh8bGg8DAP3x5uXh0srLxLKutaWInw==","ABcuQ1Vkb3Z4dm9kVUMuFwDp0r2rnJGKiIqRnKu90ukALUZSXm12eHh2bmFSQi0WAOrTvq6fkoqIiIqToq660wBBXV5jcnh0cnFoWUw+KRMA7dfCtKeYj46MiI6doqO/AFNxaGd0eG9ra2FQRDklEADw28e8sJ+VlZGIjJmYj60AXHhnYWxtYVtcUkE4MB8MAPTh0Mi/rqSln5OUn5mIpABeeGJYYWBRS0xCMysmGAgA+Oja1c2+tLWvoJ+onoiiAGB4XlFYVkY+PzcoIh8TBQD77eHe2MnBwrqqqK+iiKAAYXhbS1JOPDU2Lh8bGg8DAP3x5uXh0srLxLKutaWInw==","ABcuQ1Vkb3Z4dm9kVUMuFwDp0r2rnJGKiIqRnKu90ukALUZSXm12eHh2bmFSQi0WAOrTvq6fkoqIiIqToq660wBBXV5jcnh0cnFoWUw+KRMA7dfCtKeYj46MiI6doqO/AFNxaGd0eG9ra2FQRDklEADw28e8sJ+VlZGIjJmYj60AXHhnYWxtYVtcUkE4MB8MAPTh0Mi/rqSln5OUn5mIpABeeGJYYWBRS0xCMysmGAgA+Oja1c2+tLWvoJ+onoiiAGB4XlFYVkY+PzcoIh8TBQD77eHe2MnBwrqqqK+iiKAAYXhbS1JOPDU2Lh8bGg8DAP3x5uXh0srLxLKutaWInw=="],"wtQuark":15,"pcmSets":[{"name":"Wine Glass","short":"WGls","kind":"sus","chord":false,"overview":[0.12,0.194,0.229,0.247,0.223,0.182,0.128,0.075,0.176,0.283,0.424,0.531,0.606,0.61,0.529,0.361,0.162,0.185,0.351,0.582,0.845,0.982,1.0,0.947,0.672,0.41,0.236,0.121,0.145,0.229,0.278,0.293,0.285,0.245,0.189,0.176,0.38,0.596,0.724,0.735,0.702,0.541,0.323,0.19,0.3,0.502,0.838,0.878],"loop":[0.495,1.0],"zones":4},{"name":"Bowed Vibes","short":"BVib","kind":"sus","chord":false,"overview":[0.036,0.04,0.041,0.037,0.042,0.051,0.06,0.067,0.072,0.077,0.088,0.106,0.126,0.153,0.19,0.226,0.249,0.282,0.313,0.337,0.383,0.418,0.463,0.509,0.544,0.562,0.6,0.651,0.713,0.799,0.901,0.988,1.0,0.964,0.94,0.887,0.839,0.853,0.864,0.862,0.852,0.896,0.915,0.931,0.942,0.834,0.644,0.469],"loop":[0.384,1.0],"zones":4},{"name":"Section Strings","short":"SStr","kind":"sus","chord":false,"overview":[0.067,0.079,0.145,0.145,0.139,0.172,0.168,0.179,0.226,0.212,0.279,0.293,0.259,0.267,0.359,0.372,0.322,0.378,0.45,0.416,0.349,0.358,0.501,0.491,0.494,0.502,0.531,0.537,0.516,0.515,0.418,0.566,0.805,0.774,0.495,0.384,0.602,0.719,0.707,0.941,0.846,0.721,0.75,1.0,0.779,0.747,0.436,0.471],"loop":[0.407,1.0],"zones":6},{"name":"Psaltery","short":"Psal","kind":"sus","chord":false,"overview":[0.094,0.128,0.179,0.187,0.167,0.172,0.289,0.331,0.417,0.454,0.484,0.493,0.512,0.507,0.526,0.49,0.539,0.578,0.632,0.701,0.795,0.804,0.806,0.827,0.818,0.748,0.733,0.66,0.635,0.638,0.615,0.534,0.566,0.585,0.693,0.732,0.747,0.73,0.735,0.78,0.837,0.858,0.933,1.0,0.861,0.653,0.64,0.548],"loop":[0.33,1.0],"zones":4},{"name":"Concert Flute","short":"CFlt","kind":"sus","chord":false,"overview":[0.03,0.028,0.074,0.192,0.502,0.886,1.0,0.989,0.906,0.844,0.815,0.775,0.792,0.824,0.831,0.809,0.772,0.732,0.721,0.727,0.725,0.745,0.764,0.75,0.729,0.713,0.713,0.702,0.667,0.639,0.647,0.668,0.674,0.684,0.709,0.71,0.708,0.688,0.651,0.626,0.631,0.605,0.575,0.62,0.689,0.735,0.738,0.784],"loop":[0.265,1.0],"zones":4},{"name":"Ocarina","short":"Ocar","kind":"sus","chord":false,"overview":[0.422,0.484,0.536,0.764,0.78,0.817,0.967,0.976,0.924,0.945,1.0,0.994,0.945,0.889,0.861,0.833,0.882,0.887,0.879,0.878,0.847,0.857,0.846,0.846,0.838,0.837,0.886,0.92,0.93,0.891,0.824,0.829,0.9,0.915,0.944,0.938,0.902,0.866,0.864,0.889,0.884,0.89,0.87,0.914,0.922,0.924,0.927,0.918],"loop":[0.27,1.0],"zones":4},{"name":"Organ Blower","short":"Blwr","kind":"tex","chord":false,"overview":[0.348,0.254,0.25,0.211,0.248,0.273,0.345,0.218,0.148,0.173,0.121,0.242,0.195,0.116,0.238,0.174,0.177,0.139,0.151,0.166,0.142,0.174,0.279,0.164,0.196,0.195,0.252,0.177,0.157,0.118,0.161,0.133,0.188,0.279,0.462,0.818,0.61,0.64,0.378,0.37,0.522,1.0,0.608,0.427,0.3,0.247,0.215,0.142],"loop":[0.19,1.0],"zones":1},{"name":"Ocean Drum","short":"Ocn","kind":"tex","chord":false,"overview":[0.575,0.612,0.682,0.644,0.628,0.817,0.58,0.696,0.662,0.776,0.751,0.851,0.815,0.81,0.982,1.0,0.723,0.983,0.747,0.773,0.653,0.716,0.727,0.701,0.664,0.618,0.723,0.893,0.704,0.727,0.842,0.735,0.947,0.764,0.808,0.687,0.699,0.582,0.605,0.681,0.646,0.659,0.772,0.609,0.542,0.802,0.711,0.777],"loop":[0.21,1.0],"zones":1},{"name":"Cymbal Bow","short":"Cymb","kind":"tex","chord":false,"overview":[0.376,0.364,0.388,0.505,0.616,0.787,0.882,0.869,0.996,0.813,0.756,0.69,0.502,0.399,0.366,0.461,0.528,0.647,0.634,0.709,0.645,0.632,0.716,0.608,0.745,0.842,0.728,0.654,0.6,0.632,0.747,0.809,0.983,1.0,0.959,0.904,0.873,0.816,0.769,0.842,0.839,0.65,0.506,0.409,0.611,0.786,0.692,0.716],"loop":[0.238,1.0],"zones":1},{"name":"Gong Scrape","short":"Gong","kind":"tex","chord":false,"overview":[0.827,0.821,1.0,0.742,0.77,0.646,0.666,0.599,0.511,0.488,0.433,0.439,0.487,0.46,0.452,0.487,0.471,0.445,0.408,0.441,0.404,0.386,0.418,0.317,0.375,0.3,0.322,0.251,0.299,0.204,0.209,0.231,0.211,0.181,0.198,0.178,0.162,0.215,0.186,0.213,0.236,0.327,0.36,0.471,0.54,0.502,0.565,0.516],"loop":[0.195,1.0],"zones":1},{"name":"Hand Chimes","short":"Chim","kind":"shot","chord":false,"overview":[1.0,0.969,0.694,0.621,0.624,0.613,0.593,0.579,0.566,0.556,0.543,0.533,0.519,0.506,0.493,0.479,0.472,0.454,0.445,0.435,0.427,0.42,0.408,0.396,0.385,0.377,0.365,0.351,0.344,0.337,0.329,0.32,0.311,0.308,0.303,0.296,0.291,0.284,0.276,0.273,0.265,0.261,0.253,0.171,0.108,0.059,0.026,0.006],"loop":null,"zones":3},{"name":"Soft Vibes","short":"SVib","kind":"shot","chord":false,"overview":[0.919,1.0,0.939,0.864,0.839,0.834,0.821,0.802,0.794,0.779,0.766,0.753,0.74,0.723,0.714,0.697,0.684,0.67,0.658,0.647,0.631,0.62,0.611,0.6,0.588,0.579,0.569,0.556,0.546,0.538,0.527,0.515,0.508,0.501,0.49,0.479,0.471,0.463,0.454,0.446,0.436,0.428,0.34,0.232,0.146,0.08,0.034,0.008],"loop":null,"zones":3},{"name":"Glock","short":"Glck","kind":"shot","chord":false,"overview":[1.0,0.663,0.477,0.373,0.27,0.221,0.192,0.16,0.142,0.122,0.109,0.1,0.092,0.089,0.087,0.084,0.08,0.076,0.073,0.069,0.066,0.064,0.061,0.059,0.057,0.053,0.051,0.049,0.048,0.046,0.045,0.044,0.042,0.04,0.039,0.037,0.036,0.035,0.034,0.032,0.026,0.02,0.014,0.009,0.006,0.003,0.001,0.0],"loop":null,"zones":2},{"name":"Kalimba","short":"Kalm","kind":"shot","chord":false,"overview":[1.0,0.692,0.348,0.224,0.251,0.221,0.16,0.065,0.067,0.085,0.082,0.073,0.047,0.042,0.045,0.045,0.037,0.035,0.03,0.027,0.028,0.026,0.021,0.022,0.018,0.019,0.018,0.014,0.015,0.014,0.012,0.012,0.011,0.01,0.01,0.009,0.008,0.008,0.007,0.007,0.006,0.004,0.003,0.002,0.001,0.001,0.0,0.0],"loop":null,"zones":3},{"name":"Pipe Organ","short":"POrg","kind":"sus","chord":false,"overview":[0.307,0.485,0.465,0.333,0.413,0.362,0.374,0.619,0.678,0.651,0.684,0.77,0.904,0.981,0.945,0.957,0.883,0.928,0.972,0.941,0.863,0.825,0.851,0.943,0.947,0.919,0.916,0.931,0.907,0.918,0.923,0.88,0.935,0.964,0.96,0.972,0.963,0.955,1.0,0.987,0.979,0.897,0.84,0.865,0.84,0.802,0.829,0.972],"loop":[0.282,1.0],"zones":4},{"name":"Digi E.Piano","short":"DEP","kind":"shot","chord":false,"overview":[1.0,0.852,0.713,0.659,0.632,0.6,0.566,0.516,0.471,0.442,0.418,0.399,0.38,0.366,0.348,0.335,0.324,0.312,0.298,0.282,0.267,0.249,0.23,0.213,0.208,0.202,0.2,0.197,0.191,0.186,0.182,0.177,0.172,0.166,0.159,0.15,0.141,0.133,0.128,0.123,0.12,0.116,0.112,0.075,0.047,0.025,0.011,0.003],"loop":null,"zones":5},{"name":"Aah","short":"Aah","kind":"sus","chord":false,"overview":[0.11,0.579,0.836,0.751,0.631,0.738,0.787,0.711,0.937,0.716,0.891,0.829,0.821,0.795,0.917,0.73,0.742,0.731,0.582,0.856,0.778,0.876,0.814,1.0,0.914,0.813,0.75,0.983,0.834,0.813,0.496,0.257,0.105,0.052,0.018,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.004,0.036,0.205,0.723,0.778,0.738],"loop":[0.348,1.0],"zones":2},{"name":"Ooh","short":"Ooh","kind":"sus","chord":false,"overview":[0.078,0.123,0.192,0.198,0.262,0.291,0.29,0.311,0.185,0.188,0.172,0.2,0.246,0.301,0.386,0.264,0.409,0.583,0.674,0.629,0.68,0.713,0.804,0.862,0.955,1.0,0.974,0.865,0.584,0.484,0.443,0.459,0.43,0.344,0.244,0.173,0.207,0.271,0.313,0.4,0.438,0.498,0.517,0.534,0.607,0.719,0.733,0.678],"loop":[0.388,1.0],"zones":1},{"name":"Sung Chord","short":"SChd","kind":"sus","chord":true,"overview":[0.114,0.194,0.201,0.275,0.44,0.438,0.439,0.484,0.459,0.684,0.715,0.748,0.727,0.785,0.654,0.644,0.795,0.749,0.789,0.84,0.69,0.794,0.796,0.851,0.861,0.935,0.957,0.702,0.67,0.738,0.75,0.793,0.968,1.0,0.792,0.941,0.753,0.768,0.524,0.868,0.84,0.744,0.724,0.735,0.86,0.868,0.724,0.801],"loop":[0.347,1.0],"zones":1},{"name":"Dream Chord","short":"Drm","kind":"sus","chord":true,"overview":[0.207,0.223,0.214,0.192,0.161,0.242,0.36,0.395,0.477,0.562,0.397,0.43,0.564,0.552,0.419,0.442,0.549,0.734,0.703,0.652,0.703,0.778,0.927,0.865,0.76,0.83,0.993,1.0,0.956,0.88,0.709,0.884,0.846,0.961,0.775,0.871,0.919,0.644,0.787,0.797,0.46,0.695,0.707,0.622,0.689,0.541,0.637,0.625],"loop":[0.365,1.0],"zones":1},{"name":"Breath Loop","short":"BrLp","kind":"tex","chord":false,"overview":[0.101,0.174,0.227,0.588,0.771,1.0,0.826,0.794,0.613,0.918,0.271,0.317,0.05,0.014,0.021,0.011,0.003,0.005,0.005,0.248,0.357,0.395,0.491,0.485,0.479,0.437,0.226,0.224,0.164,0.064,0.026,0.03,0.02,0.024,0.019,0.003,0.002,0.002,0.002,0.002,0.043,0.105,0.399,0.591,0.817,0.741,0.682,0.921],"loop":[0.196,1.0],"zones":1},{"name":"Shakuhachi","short":"Shak","kind":"sus","chord":false,"overview":[0.506,0.563,0.648,0.734,0.784,0.888,0.998,1.0,0.999,0.997,0.999,0.987,0.946,0.953,0.96,0.935,0.949,0.937,0.933,0.917,0.933,0.924,0.906,0.908,0.903,0.898,0.895,0.912,0.907,0.901,0.902,0.901,0.904,0.913,0.9,0.9,0.895,0.879,0.886,0.909,0.915,0.894,0.897,0.905,0.886,0.874,0.916,0.942],"loop":[0.32,1.0],"zones":4},{"name":"Shaku Breath","short":"ShBr","kind":"tex","chord":false,"overview":[0.45,0.514,0.51,0.557,0.451,0.5,0.498,0.652,0.552,0.526,0.468,0.535,0.479,0.496,0.457,0.554,0.598,0.646,0.678,0.783,0.858,0.594,0.695,0.717,0.742,0.641,0.659,0.525,0.713,0.618,0.539,0.852,0.625,0.623,0.888,0.687,0.696,0.653,0.682,0.814,0.843,0.762,0.784,1.0,0.704,0.665,0.739,0.5],"loop":[0.203,1.0],"zones":1},{"name":"Sitar","short":"Sitr","kind":"shot","chord":false,"overview":[1.0,0.537,0.561,0.591,0.447,0.306,0.164,0.114,0.64,0.493,0.399,0.374,0.402,0.225,0.184,0.163,0.114,0.128,0.878,0.495,0.5,0.487,0.358,0.292,0.287,0.298,0.254,0.182,0.123,0.08,0.088,0.106,0.114,0.138,0.127,0.106,0.404,0.302,0.219,0.155,0.24,0.241,0.164,0.082,0.032,0.016,0.008,0.001],"loop":null,"zones":2},{"name":"Tanpura","short":"Tanp","kind":"shot","chord":false,"overview":[0.05,0.056,0.399,0.323,0.323,0.514,0.69,0.87,0.949,0.979,1.0,0.987,0.926,0.849,0.777,0.711,0.701,0.703,0.7,0.698,0.705,0.704,0.727,0.712,0.72,0.672,0.578,0.5,0.449,0.391,0.364,0.34,0.306,0.275,0.259,0.24,0.226,0.215,0.18,0.167,0.143,0.128,0.122,0.118,0.09,0.054,0.019,0.004],"loop":null,"zones":2},{"name":"Dan Tranh","short":"DanT","kind":"shot","chord":false,"overview":[1.0,0.688,0.463,0.265,0.24,0.3,0.219,0.192,0.217,0.241,0.236,0.238,0.207,0.204,0.178,0.166,0.162,0.127,0.088,0.086,0.073,0.069,0.067,0.047,0.04,0.028,0.026,0.023,0.021,0.024,0.025,0.025,0.029,0.026,0.024,0.024,0.022,0.022,0.021,0.021,0.017,0.016,0.016,0.01,0.005,0.003,0.001,0.0],"loop":null,"zones":4},{"name":"Duduk","short":"Dudk","kind":"sus","chord":false,"overview":[0.057,0.253,0.803,0.833,0.815,0.81,0.816,0.817,0.839,0.848,0.869,0.87,0.86,0.883,0.901,0.89,0.899,0.899,0.918,0.918,0.926,0.937,0.942,0.933,0.934,0.939,0.948,0.95,0.95,0.947,0.947,0.954,0.973,0.987,0.992,0.991,0.986,0.996,1.0,0.97,0.963,0.936,0.927,0.91,0.913,0.884,0.889,0.892],"loop":[0.37,1.0],"zones":1},{"name":"Erhu","short":"Erhu","kind":"sus","chord":false,"overview":[0.325,0.877,1.0,0.956,0.936,0.825,0.829,0.828,0.815,0.813,0.834,0.844,0.844,0.819,0.851,0.933,0.953,0.939,0.909,0.864,0.82,0.787,0.787,0.903,0.982,0.978,0.926,0.86,0.785,0.729,0.668,0.777,0.829,0.844,0.731,0.734,0.685,0.541,0.505,0.513,0.624,0.627,0.606,0.562,0.461,0.548,0.721,0.923],"loop":[0.372,1.0],"zones":1},{"name":"Sarangi","short":"Sarg","kind":"sus","chord":false,"overview":[0.946,0.761,0.996,0.71,0.727,0.985,0.972,0.981,1.0,0.981,0.983,0.995,0.996,0.977,0.991,0.98,0.98,0.98,0.988,0.997,0.979,0.994,0.986,0.976,0.981,0.985,0.98,0.998,0.99,0.983,0.983,0.985,0.992,0.988,0.983,0.991,0.986,0.983,0.975,0.993,0.979,0.983,0.979,0.974,0.976,0.976,0.968,0.988],"loop":[0.308,1.0],"zones":1},{"name":"Koto","short":"Koto","kind":"shot","chord":false,"overview":[1.0,0.787,0.408,0.3,0.256,0.212,0.194,0.198,0.195,0.178,0.171,0.162,0.152,0.138,0.124,0.111,0.1,0.093,0.087,0.082,0.077,0.075,0.075,0.076,0.075,0.073,0.071,0.068,0.067,0.066,0.067,0.07,0.072,0.073,0.073,0.073,0.072,0.071,0.069,0.067,0.063,0.059,0.055,0.036,0.023,0.013,0.006,0.001],"loop":null,"zones":1},{"name":"Singing Bowl","short":"Bowl","kind":"shot","chord":false,"overview":[1.0,0.47,0.414,0.394,0.351,0.33,0.312,0.303,0.298,0.294,0.287,0.276,0.263,0.248,0.235,0.222,0.209,0.202,0.191,0.181,0.18,0.172,0.169,0.162,0.155,0.147,0.14,0.132,0.126,0.118,0.115,0.111,0.108,0.107,0.102,0.099,0.099,0.091,0.087,0.085,0.079,0.075,0.073,0.07,0.07,0.066,0.027,0.007],"loop":null,"zones":1},{"name":"Didgeridoo","short":"Didg","kind":"tex","chord":false,"overview":[0.53,0.58,0.583,0.568,0.611,0.6,0.579,0.656,0.602,0.587,0.583,0.509,0.507,0.539,0.532,0.603,0.61,0.652,0.643,0.699,0.769,0.78,0.725,0.71,0.732,0.693,0.738,0.777,0.807,0.811,0.833,0.815,0.837,0.812,0.93,1.0,0.987,0.97,0.995,0.967,0.889,0.939,0.96,0.918,0.774,0.72,0.677,0.635],"loop":[0.231,1.0],"zones":1}],"pcmTypes":[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31],"wtUser0":89,"anSrc":[[1,0,0,0,0],[0,1,0,0,0],[0,0,1,0,0],[0,0,0,1,0],[0,0,0,0,1],[1,0,2,0,0],[1,2,0,0,0],[1,0,0,2,0],[1,0,0,0,2],[0,1,2,0,0],[0,1,0,2,0],[0,1,0,0,2],[0,0,1,2,0],[0,0,1,0,2],[0,0,0,1,2]],"anTargets":["Var","Ptch","Filt","Pan","Amp"],"lineVA":4,"amWaves":61,"wtQuarkDense":10,"chordFrames":[["Root","5th","5 + 8","5 + 12","5 + 9","5ths x4","5ths x5","Sub 5ths"],["5th","m","m7","m9","m11 open","m11","m11 wide","Sub m11"],["5th","Maj","Maj7","Maj9","Maj9 open","Maj9 wide","Maj13","Sub Maj9"],["5th","Maj","7","9","9sus4","11","13","Sub 11"],["4th","4ths x3","4ths x4","4ths x5","So What","So What 8","4ths x6","Sub 4ths"]],"shimSemis":[-12,-7,-5,5,7,12,19,24],"delayDivs":["1/32","1/16T","1/16","1/8T","1/16D","1/8","1/4T","1/8D","1/4","1/2T","1/4D","1/2"],"arpRates":["1/4","1/8D","1/8","1/8T","1/16","1/16T","1/32"],"arpRhythms":[[3,2],[1,2],[5,3],[1,3],[3,3],[11,4],[9,4],[13,4],[7,4],[5,5],[9,5],[13,5],[19,5],[17,5],[23,5],[37,6],[25,6],[11,6],[49,6],[39,6],[45,7],[41,7],[105,7],[21,7],[73,7],[91,7],[81,8],[45,8],[37,8],[107,8],[77,8],[89,8],[177,8],[677,12],[361,11],[1105,11],[1333,12],[3373,13],[2345,13],[2193,13]],"arpRhythmStr":["00","0x","0x0","0xx","00x","00x0","0xx0","0x00","000x","0x0xx","0xx0x","0x00x","00xx0","0xxx0","000x0","0x0xx0","0xx00x","00x0xx","0xxx00","000xx0","0x00x0x","0xx0x0x","0xx0x00","0x0x0xx","0xx0xx0","00x00x0","0xxx0x0x","0x00x0xx","0x0xx0xx","00x0x00x","0x00xx0x","0xx00x0x","0xxx00x0","0x0xx0x0x0xx","0xx0x00x0xx","0xxx0x0xxx0","0x0x00xx0x0x","0x00x0xx0x00x","0xx0x0xx0xx0x","0xxx0xx0xxx0x"],"arpPatterns":["1-3-2-4","1-2-4-3","1-4-2-3","2-4-1-3","1-3-4-2","1-3-2-4-3-5","1-2-3-2-4-3","1-4-2-3-5-3","2-3-1-4-2-5","1-2-4-3-5-2","1-3-2-4-3-5-4-2","1-2-3-2-1-4-3-5","1-4-2-3-5-4-2-1","2-3-1-4-2-5-3-1","1-2-4-3-5-4-3-2","(1-2)-(3-4)","(1-3)-(2-4)","(1-2)-(1-2-3)","(1-3)-(1-4-5)","(2-3)-(1-4)","(1-2)-3-(3-4)","(1-2)-(3-4)-2","(1-3)-(2-4)-1","(1-2-3)-(1-4)-2","(2-3)-(1-4-5)-3","(1-2)-3-(3-4)-1","(1-2)-(3-4)-(2-3)-1","(1-3)-2-(2-4)-3","(1-2-3)-(2-4)-3-1","(2-3)-(1-4)-2-(3-5)","(1-2)-(1-2-3)-(3-4)","(1-3)-(2-4)-(1-4-5)","(1-2-3)-(1-4)-(2-3)","(2-3)-(1-4-5)-(1-2)","(1-3)-(2-4)-(3-5)","(1-2-3)-(2-3-4)-(1-4)","(1-2)-(2-3-4)-(1-4-5)","(1-3-4)-(2-4)-(1-2-5)","(2-3-5)-(1-4)-(1-2-3)","(1-2-4)-(2-3-5)-(1-3-4)"],"arpOctSeq":[[0],[0,1],[0,1,2],[0,1,2,3],[0,-1],[0,-1,-2],[0,-1,-2,-3],[-1,0,1],[-2,-1,0,1,2]]};
/* Quark UI helpers shared by canvas.js (cell widgets), cards.js (parameter cards) and the browser
 * test page. tools/gen.py pastes this file (and QUARK_META) into each of them, because Schwung loads
 * every script into its own closure. Every value curve here mirrors src/dsp: change both together. */
var Q = (function () {
  var M = QUARK_META;
  var byKey = {}, byName = {};
  M.params.forEach(function (p, i) { p.index = i; byKey[p.key] = p; byName[p.name] = p; });

  function num(v, d) {
    if (v === null || v === undefined || v === "") return d;
    var x = Number(v);
    return isFinite(x) ? x : d;
  }
  /* values maps may carry host prefixes ("synth:tx_var") or :effective suffixes */
  function val(values, key) {
    var p = byKey[key], d = p ? p["default"] : 0;
    if (!values) return d;
    if (values[key + ":effective"] !== undefined && values[key + ":effective"] !== null) return num(values[key + ":effective"], d);
    if (values[key] !== undefined && values[key] !== null) return num(values[key], d);
    for (var k in values) {
      if (values[k] === null || values[k] === undefined) continue;
      var bare = k.indexOf(":") >= 0 ? k.slice(k.indexOf(":") + 1) : k;
      if (bare === key) return num(values[k], d);
    }
    return d;
  }

  function hz(note) { return 440 * Math.pow(2, (note - 69) / 12); }
  function fmtHz(f) { return f >= 1000 ? (f / 1000).toFixed(f >= 10000 ? 1 : 2) + " kHz" : Math.round(f) + " Hz"; }
  function fmtS(s) { return s < 1 ? Math.round(s * 1000) + " ms" : s.toFixed(s < 10 ? 2 : 1) + " s"; }
  function pct(x) { return Math.round(x * 100) + "%"; }
  function bip(x) { return (x > 0 ? "+" : "") + Math.round(x * 100) + "%"; }
  var NOTE = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"];
  function noteName(n) { n = Math.round(n); return NOTE[((n % 12) + 12) % 12] + (Math.floor(n / 12) - 2); }

  function envTime(x) { x = Math.max(0, Math.min(1, x)); return 0.001 + 12 * x * x * x; }
  var REGS = ["Violin", "Viola", "Cello", "Brass", "Organ", "Choir"];

  /* ---- waveforms (one cycle, t in 0..1) ---- */
  function regAt(s, v) {
    var pts = M.strings[s], c = pts.length;
    var x = Math.max(0, Math.min(1, v)) * (c - 1), i = Math.min(Math.floor(x), c - 2), f = x - i;
    return pts[i].map(function (a, j) { return a + (pts[i + 1][j] - a) * f; });
  }
  /* wave-bank previews: 8 frames x 32 int8 samples per table, base64 (tools/gen.py) */
  var B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", prev = {};
  function wtPrev(ix) {
    ix = Math.max(0, Math.min(M.wt.length - 1, ix | 0));
    if (prev[ix]) return prev[ix];
    var s = M.wt[ix], out = [], acc = 0, bits = 0;
    for (var i = 0; i < s.length; i++) {
      var c = B64.indexOf(s.charAt(i));
      if (c < 0) continue;
      acc = (acc << 6) | c; bits += 6;
      if (bits >= 8) { bits -= 8; var b = (acc >> bits) & 255; out.push(b > 127 ? b - 256 : b); }
    }
    prev[ix] = out;
    return out;
  }
  /* one sample of wave-bank table ix at position v (0..1) and phase t */
  function bankWave(ix, v, t) {
    var d = wtPrev(ix), F = 8, N = 32, pk = 1;
    var pos = Math.max(0, Math.min(1, v)) * (F - 1), k = Math.min(Math.floor(pos), F - 2), f = pos - k;
    var x = (t - Math.floor(t)) * N, i = Math.floor(x) % N, fr = x - Math.floor(x), j = (i + 1) % N;
    var a = d[k * N + i] + (d[k * N + j] - d[k * N + i]) * fr;
    var b = d[(k + 1) * N + i] + (d[(k + 1) * N + j] - d[(k + 1) * N + i]) * fr;
    for (var q = k * N; q < (k + 2) * N; q++) pk = Math.max(pk, Math.abs(d[q]));
    return (a + (b - a) * f) / pk * 0.95;
  }
  function isAmino(ix) { return ix >= M.wtQuark; }
  /* chord-stack tables name their frames (the voicing Variation is on), else null */
  function chordFrames(ix) { return ix >= M.wtQuarkDense && ix < M.wtQuark ? M.chordFrames[ix - M.wtQuarkDense] : null; }
  /* the drive transfer curve (mirrors q_drive_set / q_drive_run, without the tone filter) */
  function sclip(u) { return u > 1 ? 1 : u < -1 ? -1 : 1.5 * u - 0.5 * u * u * u; }
  function driveCurve(x, amt, pre, ref) {
    pre = pre || 1; ref = ref || 0.8;
    var g = (1 + 24 * amt * amt) * pre, bias = 0.15 * amt, off = sclip(bias);
    var pk = sclip(ref * g + bias) - off, comp = (pk > 1e-4 ? ref / pk : 1) / (1 + 0.6 * amt);
    var wet = Math.min(1, amt * 6), y = (sclip(x * g + bias) - off) * comp;
    return x + (y - x) * wet;
  }
  /* detune offset in cents for chord voice i (mirrors DET_PAT in tex.c) */
  var DET_PAT = [0.62, -0.85, 0.33, -0.48, 1.0, -0.2, 0.78, -0.66, 0.15, -1.0, 0.5, -0.36];
  function detCents(i, det) { return det * det * 45 * DET_PAT[i % 12]; }
  /* pcmB: the PCM B value (0 = Off, else set index + 1); only PCM types use it */
  function texWave(type, v, t, pcmB) {
    var tt = M.texTypes[Math.max(0, Math.min(M.texTypes.length - 1, Math.round(type)))];
    t -= Math.floor(t);
    if (tt.family === 0) {
      var r = regAt(tt.index, v), out = 0, norm = 0;
      var p = [t, (t * 2) % 1, (t * 4) % 1, (t * 8) % 1];
      for (var j = 0; j < 3; j++) { out += r[j] * (2 * p[j] - 1); norm += r[j] * r[j]; }
      for (j = 0; j < 4; j++) { out += r[3 + j] * (p[j] < 0.5 ? 1 : -1); norm += r[3 + j] * r[3 + j]; }
      return norm ? out / Math.sqrt(norm) * 0.7 : 0;
    }
    if (tt.family === 1) return bankWave(tt.index, v, t);
    if (tt.family === 3) {
      /* PCM: the set's level outline (from the ROM, the zone nearest E4) blended with PCM B's by
       * Variation, drawn as a waveform under that envelope; no B: one outline */
      var bi = Math.round(Number(pcmB) || 0) - 1, oa = M.pcmSets[M.pcmTypes[tt.index]].overview;
      var ob = bi >= 0 && M.pcmSets[bi] ? M.pcmSets[bi].overview : oa;
      var w = bi >= 0 ? Math.max(0, Math.min(1, v)) : 0, at = t * (oa.length - 1), i0 = Math.floor(at), fr = at - i0;
      var ea = oa[i0] + ((oa[i0 + 1] || 0) - oa[i0]) * fr, eb = ob[i0] + ((ob[i0 + 1] || 0) - ob[i0]) * fr;
      return 0.95 * ((1 - w) * ea + w * eb) * Math.sin(2 * Math.PI * t * 23);
    }
    var fm = M.fm[tt.index], tau = 2 * Math.PI;
    var m1 = Math.sin(tau * t * fm[0]) * v * fm[1], m2 = Math.sin(tau * t * fm[2]) * fm[3] * 0.5;
    return Math.sin(tau * t + m1 + m2);
  }
  function lineShape(shape) { return Math.max(0, Math.min(M.lineVA + M.wt.length - 1, Math.round(Number(shape) || 0))); }
  function lineIsWave(shape) { return lineShape(shape) >= M.lineVA; }
  function lineWave(shape, v, t) {
    t -= Math.floor(t);
    shape = lineShape(shape);
    if (shape >= M.lineVA) return bankWave(shape - M.lineVA, v, t);
    var pwm = Math.min(1, v * 3), w = 0.5 - 0.35 * pwm;
    var saw = 2 * t - 1, pul = t < w ? 1 : -1;
    shape = Math.round(shape);
    if (shape === 0) return saw * 0.9;
    if (shape === 1) return pul * 0.85;
    if (shape === 2) return 0.5 * (saw + pul);
    var s2 = (t * 2.6) % 1;
    return 2 * s2 - 1;
  }
  /* the Motion LFO shapes (mirrors lfo_shape in tex.c); S&H / Random Walk use fixed dice per cycle,
   * `seed` offsets them so LFO 2 draws its own values */
  var DICE = [0.6, -0.8, 0.2, 0.9, -0.4, -0.1, 0.7, -0.6];
  function lfoShape(shape, ph, seed) {
    var c = Math.floor(ph) + (seed || 0), t = ph - Math.floor(ph);
    var h = DICE[((c % 8) + 8) % 8], pv = DICE[((c - 1) % 8 + 8) % 8];
    switch (shape) {
      case 0: return Math.sin(2 * Math.PI * t);
      case 1: return t < 0.5 ? 4 * t - 1 : 3 - 4 * t;
      case 2: return 2 * t - 1;
      case 3: return t < 0.5 ? 1 : -1;
      case 4: return h;
      default: var s = t * t * (3 - 2 * t); return pv + (h - pv) * s;
    }
  }
  function familyName(type) {
    var tt = M.texTypes[Math.max(0, Math.min(M.texTypes.length - 1, Math.round(type)))];
    return ["STRINGS", "WAVETABLE", "FM", "PCM"][tt.family];
  }
  function variationText(values) {
    var type = Math.round(val(values, "tx_type")), v = val(values, "tx_var");
    var tt = M.texTypes[Math.max(0, Math.min(M.texTypes.length - 1, type))];
    if (tt.family === 0) {
      if (tt.index === 0) {
        var x = v * 5, i = Math.min(4, Math.floor(x)), f = x - i;
        return f < 0.15 ? REGS[i] : f > 0.85 ? REGS[i + 1] : REGS[i] + ">" + REGS[i + 1];
      }
      if (tt.name === "Choir") return ["Ooh", "Oh", "Aah", "Eh", "Eee"][Math.min(4, Math.round(v * 4))];
      return pct(v) + " bright";
    }
    if (tt.family === 1) return isAmino(tt.index) ? "Wave " + (1 + Math.round(v * (M.amWaves - 1))) + "/" + M.amWaves :
      chordFrames(tt.index) ? chordFrames(tt.index)[Math.round(Math.max(0, Math.min(1, v)) * 7)] : "Frame " + (1 + v * 7).toFixed(1) + "/8";
    if (tt.family === 3) {
      var na = M.pcmSets[M.pcmTypes[tt.index]].name, b2 = Math.round(val(values, "pcm_b")) - 1;
      if (b2 < 0 || !M.pcmSets[b2]) return "Start " + pct(v);
      var nb = M.pcmSets[b2].name;
      return v < 0.03 ? na : v > 0.97 ? nb : na + ">" + nb + " " + pct(v);
    }
    return "FM index " + (v * M.fm[tt.index][1]).toFixed(2);
  }

  /* reverb pre-delay in seconds, scaled by Reverb Size (mirrors q_reverb) */
  function revPre(size) { return 0.005 + 0.07 * size; }
  /* where Var Env takes Melody Variation at full envelope: it scales to the room left, so
   * any Variation + Var Env lands inside the range (mirrors lines.c) */
  function wenvTo(pos, we) { return pos + we * (we >= 0 ? 1 - pos : pos); }

  /* ---- value text in real units (mirrors the DSP) ---- */
  function describe(key, values) {
    var x = val(values, key), p = byKey[key];
    var fxt = Math.round(val(values, "fx_type"));
    switch (key) {
      case "tx_a": case "tx_d": case "tx_r": case "me_a": case "me_d": case "me_r": return fmtS(envTime(x));
      case "ln_a": return fmtS(0.5 * envTime(x));
      case "ln_d": return fmtS(0.005 + 0.9 * envTime(x));
      case "tx_type": return p.opts[Math.round(x)];
      case "an_lfo2": return (x < 0 ? "-" : "+") + Math.abs(x).toFixed(2) + "x";
      case "tx_var": return variationText(values);
      case "flt_cut": return fmtHz(hz(20 + 115 * x));
      case "flt_res": {
        var ftn = byKey.flt_type.opts[Math.round(val(values, "flt_type"))];
        if (ftn === "Morph") return x < 0.02 ? "LP" : x > 0.98 ? "HP" : Math.abs(x - 0.5) < 0.02 ? "BP" : (x < 0.5 ? "LP>BP " : "BP>HP ") + pct(x < 0.5 ? 2 * x : 2 * x - 1);
        if (ftn === "Comb+" || ftn === "Comb-") return "Fdbk " + pct(0.3 + 0.66 * x);
        return pct(x);
      }
      case "ln_cut": return fmtHz(hz(20 + 115 * x));
      case "flt_env": case "ln_fenv": return (x >= 0 ? "+" : "") + Math.round(x * 72) + " st";
      case "an_rate": return (0.03 * Math.pow(333, x)).toFixed(2) + " Hz";
      case "vib_rate": return (3 + 6 * x).toFixed(1) + " Hz";
      case "tx_spread": return "±" + (x * 9).toFixed(1) + " ct";
      case "ln_det": return Math.round(x) + " ct";
      case "ln_glide": return fmtS(1.2 * x * x);
      case "rv_decay": return x > 0.995 ? "Freeze" : fmtS(0.35 * Math.pow(80, x));
      case "rv_tone": return fmtHz(1200 * Math.pow(13, x));
      case "rv_size": return pct(x) + ", pre " + Math.round(1000 * revPre(x)) + " ms";
      case "ln_spread": return Math.abs(x) < 0.02 ? "Centre" : (x < 0 ? "Random " : "Steps ") + pct(Math.abs(x));
      case "ln_dly": return x < 0.003 ? "Off" : pct(x);
      case "sh_pitch": return p.opts[Math.round(x)] + " st";
      case "split": return noteName(x);
      case "arp_swing": return Math.round(50 + 16.5 * x) + "%";
      case "arp_gate": return Math.round((0.05 + 1.95 * x * x) * 100) + "%";
      case "arp_rhy": return M.arpRhythmStr[Math.max(0, Math.min(M.arpRhythmStr.length - 1, Math.round(x)))];
      case "arp_pat": return M.arpPatterns[Math.max(0, Math.min(M.arpPatterns.length - 1, Math.round(x)))];
      case "arp_vel": return Math.round(x) === 0 ? "As played" : String(Math.round(x));
      case "arp_loop": return Math.round(x) === 0 ? "Free" : Math.round(x) + " steps";
      case "tx_depth": case "ln_wenv": return bip(x);
      case "ln_var":
        if (lineIsWave(val(values, "ln_shape"))) {
          var cf = chordFrames(lineShape(val(values, "ln_shape")) - M.lineVA);
          return cf ? cf[Math.round(Math.max(0, Math.min(1, x)) * 7)] : "Pos " + pct(x);
        }
        return pct(x);
      case "tx_drive": return x < 0.003 ? "Off" : "+" + (20 * Math.log10(1 + 24 * x * x)).toFixed(1) + " dB";
      case "pl_tune": { var tu = plTune(x), n = tu.st || tu.ct; return (n > 0 ? "+" : "") + n + (tu.st ? " st" : " ct"); }
      case "pl_lvl": return plSet(values) ? pct(x) : "Layer Off";
      case "pl_start": return x < 0.005 ? "Attack" : pct(x);
      case "pcm_era": return p.opts[Math.round(x)];
      case "tx_dtone": return fmtHz(700 * Math.pow(2, 5 * x));
      case "tx_detune": return "±" + (x * x * 45).toFixed(1) + " ct";
      case "tx_bloom": return x < 0.005 ? "Instant" : fmtS(0.05 + 15 * x * x);
      case "fx_ctrl":
        if (fxt <= 1) return (0.08 * Math.pow(60, x)).toFixed(2) + " Hz";
        if (fxt <= 3) return (0.03 * Math.pow(100, x)).toFixed(2) + " Hz";
        if (fxt <= 5) return (0.03 * Math.pow(150, x)).toFixed(2) + " Hz";
        if (fxt === 6) return (0.5 * Math.pow(28, x)).toFixed(1) + " Hz";
        if (fxt === 7) return "+" + (20 * Math.log10(1 + 30 * x * x)).toFixed(1) + " dB";
        return M.delayDivs[Math.max(0, Math.min(11, Math.floor(x * 11.99)))];
      case "fx_tone":
        if (fxt <= 1) return "Depth " + pct(x);
        if (fxt <= 5) return "Fdbk " + pct(x);
        if (fxt === 6) return "Shape " + pct(x);
        if (fxt === 7) return "Tone " + fmtHz(700 * Math.pow(17, x));
        return "Fdbk " + pct(x * 0.92);
    }
    if (p && p.kind === "e") return p.opts[Math.round(x)];
    if (p && p.kind === "i") return String(Math.round(x)) + (p.unit ? " " + p.unit : "");
    if (p && p.mn < 0) return bip(x);
    return pct(x);
  }
  /* The first steps an arp type plays from a 3-note chord: arrays of pitch indices (0 = lowest note,
   * +3 per octave). Mirrors arp_tick in quark.c (Random shows a fixed sample). */
  function arpPreview(values, steps) {
    var mode = Math.round(val(values, "arp_mode")), oct = M.arpOctSeq[Math.max(0, Math.min(M.arpOctSeq.length - 1, Math.round(val(values, "arp_oct"))))];
    var n = 3, out = [], i, k;
    if (mode <= 0) return out;
    var lo = Math.min.apply(null, oct), hi = Math.max.apply(null, oct);
    if (mode === 7 || mode === 10) {
      var pat = M.arpPatterns[Math.max(0, Math.min(M.arpPatterns.length - 1, Math.round(val(values, "arp_pat"))))];
      var st = mode === 7 ? [[1, 2, 3]] : (pat.match(/\([^)]*\)|\d+/g) || ["1"]).map(function (t) { return (t.match(/\d+/g) || []).map(Number); });
      for (k = 0; k < steps; k++) {
        var o = oct[Math.floor(k / st.length) % oct.length], s0 = st[k % st.length], ch = [];
        s0.forEach(function (ix) {
          var j = ix <= n ? ix : ((ix - 1) % (2 * n - 2)) + 1; if (j > n) j = 2 * n - j;
          if (ch.indexOf(j - 1 + 3 * o) < 0) ch.push(j - 1 + 3 * o);
        });
        out.push(ch);
      }
      return out;
    }
    var ext = [];
    if (mode === 6) oct.forEach(function (o) { [1, 0, 2].forEach(function (j) { ext.push(j + 3 * o); }); });
    else for (var o2 = lo; o2 <= hi; o2++) for (i = 0; i < n; i++) ext.push(i + 3 * o2);
    var T = ext.length, pos = -1, dir = 1, rnd = [0.62, 0.11, 0.85, 0.37, 0.05, 0.71, 0.29, 0.93, 0.48, 0.19, 0.77, 0.55];
    for (k = 0; k < steps; k++) {
      var idx;
      if (mode === 5) idx = Math.floor(rnd[k % 12] * T);
      else if ((mode === 3 || mode === 4) && T > 1) {
        pos += dir; if (pos >= T) { pos = T - 2; dir = -1; } if (pos < 0) { pos = 1; dir = 1; }
        idx = mode === 4 ? T - 1 - pos : pos;
      } else {
        pos = (pos + 1) % T;
        var p2 = pos % T;
        if (mode === 2) idx = T - 1 - pos;
        else if (mode === 8) idx = (p2 & 1) === 0 ? p2 / 2 : T - 1 - (p2 - 1) / 2;
        else if (mode === 9) {
          if (T & 1) { var c = (T - 1) / 2, kk = Math.ceil(p2 / 2); idx = p2 === 0 ? c : c + ((p2 & 1) ? -kk : kk); }
          else { var l0 = T / 2 - 1, h0 = T / 2; idx = p2 === 0 ? l0 : (p2 & 1) ? h0 + (p2 - 1) / 2 : l0 - p2 / 2; }
        } else idx = pos;
      }
      out.push([ext[Math.max(0, Math.min(T - 1, idx))]]);
    }
    return out;
  }

  function ctrlLabel(values) {
    var t = Math.round(val(values, "fx_type"));
    return t === 7 ? "Drive" : t >= 8 ? "Time" : "Rate";
  }
  /* what Effect Control / Control 2 do for effect type t (mirrors fx.c) */
  function fxCtrlName(key, t) {
    if (key === "fx_ctrl") return ctrlLabel({ fx_type: t });
    return t <= 1 ? "Depth" : t === 6 ? "Shape" : t === 7 ? "Tone" : "Feedback";
  }

  /* ---- drawing on a Schwung frame ctx ---- */
  function line(ctx, x0, y0, x1, y1) {
    x0 = Math.round(x0); y0 = Math.round(y0); x1 = Math.round(x1); y1 = Math.round(y1);
    if (typeof ctx.line === "function") { ctx.line(x0, y0, x1, y1, 1); return; }
    var n = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0), 1);
    for (var i = 0; i <= n; i++) ctx.fillRect(Math.round(x0 + (x1 - x0) * i / n), Math.round(y0 + (y1 - y0) * i / n), 1, 1, 1);
  }
  function plot(ctx, fn, x, y, w, h, cycles) {
    var px = null, py = null;
    for (var i = 0; i < w; i++) {
      var s = fn(i / w * (cycles || 1));
      var yy = y + Math.round((0.5 - 0.5 * Math.max(-1, Math.min(1, s))) * (h - 1));
      if (px !== null) line(ctx, px, py, x + i, yy);
      px = x + i; py = yy;
    }
  }
  function tw(ctx, s) {
    if (typeof ctx.textWidth === "function") return ctx.textWidth(s);
    return String(s).length * 6;
  }
  function fit(ctx, s, maxW) {
    s = String(s);
    if (tw(ctx, s) <= maxW) return s;
    while (s.length > 1 && tw(ctx, s + ".") > maxW) s = s.slice(0, -1);
    return s + ".";
  }
  function dotted(ctx, x, y, w) { for (var i = 0; i < w; i += 2) ctx.fillRect(x + i, y, 1, 1, 1); }
  function envShape(ctx, a, d, s, r, x, y, w, h, hi) {
    var la = 0.08 + a, ld = 0.08 + d, ls = 0.35, lr = 0.08 + r, tot = la + ld + ls + lr;
    var X = function (t) { return x + t / tot * (w - 1); }, Y = function (v) { return y + (1 - v) * (h - 1); };
    var pts = [[0, 0], [la, 1], [la + ld, s], [la + ld + ls, s], [tot, 0]];
    for (var i = 0; i < 4; i++) {
      line(ctx, X(pts[i][0]), Y(pts[i][1]), X(pts[i + 1][0]), Y(pts[i + 1][1]));
      if (hi === i) line(ctx, X(pts[i][0]), Y(pts[i][1]) - 1, X(pts[i + 1][0]), Y(pts[i + 1][1]) - 1);
    }
  }
  /* Magnitude of the Atmos filter at f Hz (mirrors tex.c: SVF damping per type, comb loop with its
   * damping one-pole and output gain). Types by option name. */
  function filterMag(type, f, fc, res) {
    if (type === "Off") return 1;
    if (type === "Comb+" || type === "Comb-") {
      var fb = (0.3 + 0.66 * res) * (type === "Comb+" ? 1 : -1), w = 2 * Math.PI * f / 48000, th = 2 * Math.PI * f / fc;
      /* loop one-pole a / (1 - (1-a) e^-jw), a = 0.65 */
      var dr = 1 - 0.35 * Math.cos(w), di = 0.35 * Math.sin(w), dm = dr * dr + di * di;
      var lr = 0.65 * dr / dm, li = -0.65 * di / dm;
      var er = Math.cos(th), ei = -Math.sin(th);
      var zr = 1 - fb * (lr * er - li * ei), zi = -fb * (lr * ei + li * er);
      return (1 - 0.6 * Math.abs(fb)) / Math.sqrt(zr * zr + zi * zi);
    }
    var k = type === "LP24" || type === "BP24" ? 2 - 1.6 * res : type === "Dual BP" ? 2 - 1.8 * res : type === "Morph" ? 1 : 2 - 1.94 * res;
    function svf(fc2) {   /* returns [re, im] of the denominator and r */
      var r = f / fc2; return { r: r, dr: 1 - r * r, di: k * r };
    }
    var s = svf(fc), d2 = s.dr * s.dr + s.di * s.di, dm = Math.sqrt(d2);
    var lp = 1 / dm, bp = k * s.r / dm, hp = s.r * s.r / dm;
    if (type === "LP12") return lp;
    if (type === "LP24") return lp * lp;
    if (type === "HP12" || type === "HP") return hp;
    if (type === "BP12" || type === "BP") return 1.6 * bp;
    if (type === "BP24") return 1.6 * bp * bp;
    if (type === "Notch") return Math.abs(s.dr) / dm;
    if (type === "Dual BP") {
      /* complex sum of the two bands: H = j k r / (dr + j k r) */
      var t = svf(Math.min(fc * 2.5, 22000));
      var ar = (k * s.r * s.di) / d2, ai = (k * s.r * s.dr) / d2;
      var e2 = t.dr * t.dr + t.di * t.di, br = (k * t.r * t.di) / e2, bi = (k * t.r * t.dr) / e2;
      return Math.sqrt((ar + br) * (ar + br) + (ai + bi) * (ai + bi));
    }
    if (type === "Morph") {
      /* complex blend: LP = 1/D, BP = j k r / D, HP = -r^2 / D */
      var mo = Math.max(0, Math.min(1, res)), wl = mo < 0.5 ? 1 - 2 * mo : 0, wb = mo < 0.5 ? 2 * mo : 2 - 2 * mo, wh = mo < 0.5 ? 0 : 2 * mo - 1;
      var nr = wl - wh * s.r * s.r, ni = wb * k * s.r;
      return Math.sqrt(nr * nr + ni * ni) / dm;
    }
    return lp;
  }

  function filterCurve(ctx, cutNote, res, type, x, y, w, h) {
    var fc = hz(cutNote), px = null, py = null;
    for (var i = 0; i < w; i++) {
      var f = 20 * Math.pow(1000, i / (w - 1));
      var m = filterMag(type, f, fc, res);
      var db = 20 * Math.log(Math.max(1e-4, m)) / Math.LN10;
      var yy = y + Math.round((1 - Math.max(0, Math.min(1, (db + 30) / 48))) * (h - 1));
      if (px !== null) line(ctx, px, py, x + i, yy);
      px = x + i; py = yy;
    }
  }

  /* ---- PCM Layer ---- */
  /* (the Move font has no middle dot: plain ASCII only in card text) */
  var ERA_TEXT = ["32k, smooth", "16k, aliased", "8k, 12-bit"];
  var PL_MODE_TEXT = ["Loops, filtered", "Once, filtered", "Loops, unfiltered", "Once, unfiltered"];
  /* Layer Tune: one knob, +-50 = cents, beyond that semitones (51 = +1 st .. 74 = +24 st);
   * mirrors pl_tune_split in tex.c */
  function plTune(x) {
    var v = Math.round(Number(x) || 0), a = Math.abs(v), s = v < 0 ? -1 : 1;
    return a <= 50 ? { st: 0, ct: v } : { st: s * Math.min(24, a - 50), ct: 0 };
  }
  /* the Layer's set (null when Off) */
  function plSet(values) {
    var i = Math.round(val(values, "pl_wave")) - 1;
    return i >= 0 && M.pcmSets[i] ? M.pcmSets[i] : null;
  }
  /* where Start puts the note in the set's outline, 0..1 (mirrors layer_init: up to the loop start,
   * a one-shot up to half way) */
  function plStartFrac(st, start) {
    return Math.max(0, Math.min(1, start)) * (st && st.loop ? st.loop[0] : 0.5);
  }
  /* a set's level outline as 1-px bars every `step` columns, centred in the box */
  function pcmOutline(ctx, st, x, y, w, h, step) {
    var ov = st.overview, s = step || 1;
    for (var xo = 0; xo < w; xo += s) {
      var e = ov[Math.min(ov.length - 1, Math.floor(xo / w * ov.length))];
      var hh = Math.max(1, Math.round(e * h));
      ctx.fillRect(x + xo, y + Math.floor((h - hh) / 2), 1, hh, 1);
    }
  }
  /* a sine read the way an Era reads the ROM: Clean smooth; 90s coarse linear steps; Lo-Fi held
   * steps quantised to a few levels (the drawing exaggerates so it reads at cell size) */
  function eraWave(era, t) {
    var n = [0, 9, 6][era] || 0;
    if (!n) return Math.sin(2 * Math.PI * t) * 0.9;
    var a = t * n, i = Math.floor(a), f = a - i;
    var y0 = Math.sin(2 * Math.PI * i / n), y1 = Math.sin(2 * Math.PI * (i + 1) / n);
    if (era === 1) return 0.9 * (y0 + (y1 - y0) * f);
    return 0.9 * Math.round(y0 * 3) / 3;
  }

  return {
    plTune: plTune, plSet: plSet, plStartFrac: plStartFrac, pcmOutline: pcmOutline, eraWave: eraWave, eraText: ERA_TEXT, plModeText: PL_MODE_TEXT,
    M: M, byKey: byKey, byName: byName, val: val, num: num, hz: hz, envTime: envTime, texWave: texWave,
    lineWave: lineWave, lineIsWave: lineIsWave, bankWave: bankWave, driveCurve: driveCurve, detCents: detCents, fmtS: fmtS, envTimeS: envTime, familyName: familyName, lfoShape: lfoShape, variationText: variationText, describe: describe,
    ctrlLabel: ctrlLabel, fxCtrlName: fxCtrlName, line: line, plot: plot, tw: tw, fit: fit, dotted: dotted, envShape: envShape,
    filterCurve: filterCurve, filterMag: filterMag, noteName: noteName, pct: pct, arpPreview: arpPreview, revPre: revPre, wenvTo: wenvTo
  };
})();

  /* END GENERATED */

  function drawWave(ctx, o) {
    var W = ctx.width, H = ctx.height, v = o.values || {};
    var type = Q.val(v, "tx_type"), va = Q.val(v, "tx_var");
    var fam = Q.M.texTypes[Math.max(0, Math.min(Q.M.texTypes.length - 1, Math.round(type)))].family;
    var wh = Math.max(6, H - 4);
    var pb = Q.val(v, "pcm_b");
    Q.plot(ctx, function (t) { return Q.texWave(type, va, t, pb); }, 0, 0, W, wh, fam === 0 ? 1 : 2);
    /* variation tick + family dots */
    var by = H - 2;
    Q.dotted(ctx, 0, by, W);
    var mx = Math.round(Math.max(0, Math.min(1, va)) * (W - 1));
    ctx.fillRect(Math.max(0, mx - 1), by - 1, 3, 3, 1);
    for (var i = 0; i <= fam; i++) ctx.fillRect(W - 2 - i * 3, 0, 2, 2, 1);
  }

  function drawLine(ctx, o) {
    var W = ctx.width, H = ctx.height, v = o.values || {};
    var shape = Q.val(v, "ln_shape"), va = Q.val(v, "ln_var");
    var wh = Math.max(6, H - 5);
    Q.plot(ctx, function (t) { return Q.lineWave(shape, va, t); }, 0, 0, W, wh, 2);
    if (Q.lineIsWave(shape)) {
      var by = H - 2, mx = Math.round(Math.max(0, Math.min(1, va)) * (W - 1));
      Q.dotted(ctx, 0, by, W);
      ctx.fillRect(Math.max(0, mx - 1), by - 1, 3, 3, 1);
      return;
    }
    var seg = Math.floor((W - 4) / 3), y = H - 3;
    for (var s = 0; s < 3; s++) {
      var fill = Math.max(0, Math.min(1, va * 3 - s));
      var x = s * (seg + 2);
      ctx.fillRect(x, y, seg, 1, 1);
      if (fill > 0) ctx.fillRect(x, y - 1, Math.max(1, Math.round(seg * fill)), 3, 1);
    }
  }

  function drawDrive(ctx, o) {
    var W = ctx.width, H = ctx.height, v = o.values || {};
    var amt = Q.val(v, "tx_drive"), pos = Math.round(Q.val(v, "tx_drvpos"));
    var amp = pos === 2, s = Math.min(H - 1, Math.floor(W * 0.45));
    /* transfer curve in a square on the left */
    Q.dotted(ctx, 0, Math.floor(s / 2), s);
    var px = null, py = null;
    for (var i = 0; i < s; i++) {
      var x = (i / (s - 1)) * 2 - 1, y = Q.driveCurve(x * (amp ? 0.4 : 0.8), amt, amp ? 2.5 : 1, amp ? 0.4 : 0.8) / (amp ? 0.4 : 0.8);
      var yy = Math.round((0.5 - 0.5 * Math.max(-1, Math.min(1, y))) * (s - 1));
      if (px !== null) Q.line(ctx, px, py, i, yy);
      px = i; py = yy;
    }
    /* a sine through it on the right, with the position name */
    var x0 = s + 3, w = W - x0;
    Q.plot(ctx, function (t) {
      var x = Math.sin(2 * Math.PI * t) * (amp ? 0.4 : 0.8);
      return Q.driveCurve(x, amt, amp ? 2.5 : 1, amp ? 0.4 : 0.8) / (amp ? 0.4 : 0.8);
    }, x0, 0, w, H - 7, 1);
    var lab = ["PRE", "POST", "AMP"][pos] || "";
    ctx.print(x0, H - 7, lab, 1);
  }

  function drawDetune(ctx, o) {
    var W = ctx.width, H = ctx.height, v = o.values || {};
    var det = Q.val(v, "tx_detune"), bl = Q.val(v, "tx_bloom");
    var cy = Math.floor(H / 2), span = Math.max(1, H / 2 - 1);
    var t0 = 3, tb = bl < 0.005 ? 0 : Math.min(W - t0 - 2, Math.round((W - t0) * (0.08 + 0.85 * Math.sqrt(bl))));
    ctx.fillRect(0, cy, 2, 1, 1);
    for (var n = 0; n < 4; n++) {
      var c = Q.detCents(n, det) / 45, py = cy;
      for (var x = t0; x < W; x++) {
        var k = tb <= 0 ? 1 : Math.min(1, (x - t0) / tb);
        var y = Math.round(cy - c * k * span);
        if (x > t0) Q.line(ctx, x - 1, py, x, y);
        py = y;
      }
    }
  }

  function drawFilter(ctx, o) {
    var W = ctx.width, H = ctx.height, v = o.values || {};
    var opts = Q.byKey.flt_type.opts, ti = Math.max(0, Math.min(opts.length - 1, Math.round(Q.val(v, "flt_type"))));
    var type = opts[ti];
    var fc = Q.hz(20 + 115 * Q.val(v, "flt_cut")), res = Q.val(v, "flt_res");
    var bot = H - 1;
    Q.dotted(ctx, 0, bot, W);
    var py = null;
    for (var x = 0; x < W; x++) {
      var f = 20 * Math.pow(1000, x / Math.max(1, W - 1));
      var db = 20 * Math.log(Math.max(1e-4, Q.filterMag(type, f, fc, res))) / Math.LN10;
      var y = Math.round((1 - Math.max(0, Math.min(1, (db + 30) / 48))) * (H - 2));
      if (py !== null) Q.line(ctx, x - 1, py, x, y);
      py = y;
    }
  }

  /* the Mode glyph, 7x5 at (x, y): Loop / Air an arrow curling back, Shot / Ping a bar with a stop;
   * Air / Ping (after the filter) are boxed */
  function modeGlyph(ctx, x, y, mode) {
    if (mode === 0 || mode === 2) {
      ctx.fillRect(x + 1, y, 5, 1, 1); ctx.fillRect(x + 6, y, 1, 4, 1); ctx.fillRect(x + 1, y + 4, 6, 1, 1);
      ctx.fillRect(x, y + 3, 1, 3, 1); ctx.fillRect(x + 1, y + 4, 1, 1, 1);
    } else {
      ctx.fillRect(x, y + 2, 5, 1, 1); ctx.fillRect(x + 6, y, 1, 5, 1);
    }
    if (mode >= 2) { Q.dotted(ctx, x - 1, y - 2, 8); Q.dotted(ctx, x - 1, y + 6, 8); }
  }

  function drawPcm(ctx, o) {
    var W = ctx.width, H = ctx.height, v = o.values || {};
    var st = Q.plSet(v), mode = Math.max(0, Math.min(3, Math.round(Q.val(v, "pl_mode"))));
    var gw = W >= 40 ? 11 : 0;   /* room for the Mode glyph in a wide (grouped) cell */
    var w = W - gw, h = H - 3;
    if (!st) { Q.dotted(ctx, 0, Math.floor(h / 2), w); }
    else {
      Q.pcmOutline(ctx, st, 0, 0, w, h, w >= 40 ? 2 : 1);
      if (st.loop) {   /* loop bracket along the top */
        var lx = Math.round(st.loop[0] * (w - 1));
        ctx.fillRect(lx, 0, 1, 3, 1); ctx.fillRect(w - 1, 0, 1, 3, 1); ctx.fillRect(lx, 0, w - lx, 1, 1);
      }
    }
    var by = H - 2, sx = st ? Math.round(Q.plStartFrac(st, Q.val(v, "pl_start")) * (w - 1)) : 0;
    Q.dotted(ctx, 0, by, w);
    ctx.fillRect(Math.max(0, sx - 1), by - 1, 3, 3, 1);
    if (gw) modeGlyph(ctx, W - 8, Math.max(2, Math.floor((H - 5) / 2)), mode);
  }

  function drawEra(ctx, o) {
    var W = ctx.width, H = ctx.height, v = o.values || {};
    var era = Math.max(0, Math.min(2, Math.round(Q.val(v, "pcm_era"))));
    Q.plot(ctx, function (t) { return Q.eraWave(era, t); }, 0, 0, W, H - 1, 1);
  }

  globalThis.canvas_overlay = {
    widgetKinds: {
      "custom:qwave": drawWave,
      "custom:qline": drawLine,
      "custom:qdrive": drawDrive,
      "custom:qdet": drawDetune,
      "custom:qflt": drawFilter,
      "custom:qpcm": drawPcm,
      "custom:qera": drawEra,
    },
  };
})();
